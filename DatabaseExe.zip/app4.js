
//http://localhost:3000/public/login.html - 로그인
//http://localhost:3000/public/addUser.html - 회원가입
//http://localhost:3000/public/listUser.html - 리스트
//비밀번호 암호화
//crypto 모듈 : 암호화 한다.
//암호화 방법 : 사용자가 입력한 pwd + salt key(내가 임의로 만들 수 있다) = 암호화
//같은 숫자의 암호화된것은 암호화해도 같다.

var express = require("express");
var http = require("http");
var path = require("path");

var serveStatic = require("serve-static"); //특정 폴더로 접근 가능하게 함
var expressErrorHandler = require("express-error-handler");
var cookieParser = require("cookie-parser");
var expressSession = require("express-session");

var mongoose = require("mongoose");

//crypto 모듈
var crypto = require("crypto");

//익스프레스 객체 생성
var app = express(); 

//기본 포트를 app객체에 속성으로 설정
//express 객체의 메소드 (set,get,use)
app.set("port",process.env.PORT || 3000); 

//미들웨어 추가
app.use(express.urlencoded({extended: true})); 
app.use(express.json()); 

//사용할 주소 /public
app.use("/public",serveStatic(path.join(__dirname,"public")));



//데이터베이스 객체를 위한 변수
var database;

//데이터베이스 컬렉션에 적용할 스키마 객체를 위한 변수
var UserSchema; //규칙 만들기

//데이터베이스 모델 객체를 위한 변수
var UserModel; //규칙 적용

function connectDB() {
	
	//데이터베이스 연결 정보
	var databaseUrl = "mongodb://localhost:27017/shopping"; //아이피주소보다 localhost
	
	//몽구스로 데이터베이스 연결 - MongoDB연결에는 이 기능이 없다.
	mongoose.connect(databaseUrl); //DB 연결
	database = mongoose.connection; //DB연결되던 안되던 무조건 on 실행
	//모듈 내부적 emit가지고 있어서 자동으로 open이나 error,disconnected (예약어)찾아가게 한다.
	
	database.on("open",function() {//이벤트, 예약어
		
		console.log("데이터베이스에 연결되었습니다. : " + databaseUrl);
		
		createUserSchema();
		
	});
	
	database.on("error",console.error.bind(console,"몽구스 연결 에러.."));
	
	database.on("disconnected",function() {
		
		console.log("데이터베이스 연결이 끊겼습니다");
		setInterval(connectDB(),5000); //연결이 끊기면 5초후 재연결
		
	});
	
}


//스키마 및 모델 객체 생성 함수
function createUserSchema() {
	
	//스키마 정의
	UserSchema = mongoose.Schema({
		
		id:{type:String, required: true, unique: true},
		name:{type:String, index:"hashed"},
		hashed_password:{type:String, required: true}, //암호화된 비밀번호
		salt:{type:String, required: true}, //데이터 비교 위해 꼭 보존해야한다
		age:{type:Number, "default":20},
		created:{type:Date, index:{unique:false},"default":Date.now}
		
	});
	
	//virtual 속성
	UserSchema.virtual("password")
	.set(function(password) {
		
		this._password = password; //_구분위해 붙임. 안 붙여도 됨. //사용자가 입력한 패스워드 - 버림
		this.salt = this.makeSalt(); //key값 생성
		this.hashed_password = this.encryptPassword(password); //암호화된 패스워드
		
	})
	.get(function() {
		return this._password;
	});
	
	//스키마에 method로 추가
	UserSchema.method("encryptPassword",function(inputPwd,inSalt) {//사용자입력비번,salt
		
		if(inSalt) {
			return crypto.createHmac("sha1",inSalt).update(inputPwd).digest("hex"); //쉬바 : 암호화 하는 기술 (sha1,sha2,sha3) 3가지
		}else {
			return crypto.createHmac("sha1",this.salt).update(inputPwd).digest("hex"); //this.salt는 내부적으로 만든것
		}
		
	});
	
	UserSchema.method("makeSalt",function() {//데이터 비교 위해 보존해야 한다 - DB저장
		
		console.log("date: " + new Date().valueOf()); //날짜를 숫자로 보여줌 = 1572856039737
		console.log("math: " + Math.random()); //랜덤숫자 = 0.8524552533483953
		//위 두 값을 만들어 salt 만든다
		
		//round : 소숫점 아래 버림
		return Math.round((new Date().valueOf() * Math.random())) + ""; //""해주면 문자로 변환된다.(숫자 + 문자 = 문자 : 자바문법) //사용자 정의
		
	});
	
	//인증 메소드(입력된 비밀번호와 비교작업)
	UserSchema.method("authenticate",function(inputPwd,inSalt,hashed_password) {//inputPwd+inSalt로 암호화 vs 이미 암호화된 hashed_password - 비교
		
		if(inSalt) {
			
			console.log("inputPwd: " + inputPwd);
			console.log("encryptPassword: " + this.encryptPassword(inputPwd,inSalt));
			console.log("hashed_password: " + hashed_password);
			
			return this.encryptPassword(inputPwd,inSalt)===hashed_password;
			
		}else {
			
			console.log("inputPwd: " + inputPwd);
			console.log("encryptPassword: " + this.encryptPassword(inputPwd));
			console.log("hashed_password: " + hashed_password);
			
			return this.encryptPassword(inputPwd)===this.hashed_password;
			
		}
		
	});
	
	
	//스키마 객체에 메소드 추가 (static(), method() : 2가지 방법)
	
	//스키마에 static으로 findById 메소드 추가(로그인에서 사용)
	UserSchema.static("findById",function(id,callback) {
		return this.find({id:id},callback); //db에서 id로 검색
	});
	
	//스키마에 static으로 findAll 메소드 추가(전체데이터 가져오기)
	UserSchema.static("findAll",function(callback) {
		return this.find({}, callback); //검색조건 없음
	});
	
	console.log("UserSchema 정의함");
	
	//Schema를 collection에 model로 적용
	UserModel = mongoose.model("users3",UserSchema); //insert시에 자동으로 컬렉션 만들어진다.
	console.log("UserModel 정의함");
	
}

//사용자 인증 함수 (로그인할 때 사용)
var authUser = function(database,id,password,callback) {
	
	console.log("authUser 호출");
	
	//id를 이용해서 검색
	UserModel.findById(id,function(err,result) {//callback 함수
		
		if(err) {
			callback(err,null); //에러만 전달하고 데이터는 null전달
			return;
		}
		
		if(result.length>0) {//데이터 찾음
			
			var user = new UserModel({id:id});
			
			var authenticate = user.authenticate(password,result[0]._doc.salt,result[0]._doc.hashed_password);
			
			if(authenticate) {
				console.log("비밀번호 일치함.");
				callback(null,result);
			}else {
				console.log("비밀번호 일치하지 않음.");
				callback(null,null);
			}
			
		}else {//사용자 찾지 못함
			
			console.log("아이디와 일치하는 사용자를 찾지 못함");
			callback(null,null); //에러는 아닌데 일치사용자 없음
			
		}
		
	});
	
};

//사용자 추가 함수
var addUser = function(databas,id,pwd,name,callback) {
	
	console.log("addUser 호출");
	
	//var users = database.collection("users");
	
	var user = new UserModel({"id":id,"password":pwd,"name":name});
	
	user.save(function(err,result) {
		
		if(err) {
			callback(err,null);
			return;
		}
		/*
		if(result.insertedCount>0) {//배열검증
			
		}
		*/
		
		if(result) {
			console.log("사용자 추가");
		}else {
			console.log("사용자 추가 안됨");
		}
		
		callback(null,result);
		
	});
	
};

//라우터 객체
var router = express.Router();

//사용자 로그인 라우터
router.route("/process/login").post(function(req,res) {//id,password 보냄
	
	console.log("login 호출");
	
	var id = req.body.id;
	var pwd = req.body.pwd;
	
	//사용자 인증
	if(database) {//database 연결되어야 있어야함
		
		authUser(database, id, pwd, function(err,result) {//callback함수
			
			if(err) {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h1>사용자 로그인 에러!!</h1>");
				res.end();
				
				return;
				
			}
			
			if(result) {//result 있으면
				
				var userName = result[0].name;
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h1>로그인 성공!!</h1>");
				res.write("<div>아이디: " + id + "</div>");
				res.write("<div>이름: " + userName + "</div>");
				res.write("<br/><br/><a href='/public/login.html'>로그인</a>");
				res.write("<br/><br/><a href='/public/listUser.html'>리스트</a>");
				res.end();
				
			}else {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h1>로그인 실패!!</h1>");
				res.write("<div>아이디와 패스워드를 다시 확인하세요.</div>");
				res.write("<br/><br/><a href='/public/login.html'>로그인</a>");
				res.write("<br/><br/><a href='/public/listUser.html'>리스트</a>");
				res.end();
				
			}
			
		});
		
	}else {
		
		res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
		res.write("<h1>데이터베이스 연결 실패!!</h1>");
		res.write("<div>데이터베이스에 연결하지 못했습니다.</div>");
		res.end();
		
	}
	
});

//사용자 추가 라우터
router.route("/process/addUser").post(function(req,res) {
	
	console.log("addUser 호출");
	
	var id = req.body.id;
	var pwd = req.body.pwd;
	var name = req.body.name;
	
	if(database) {
		
		addUser(database, id, pwd, name, function(err,result) {
			
			if(err) {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h1>사용자 추가 에러!!</h1>");
				res.end();
				
				return;
				
			}
			
			if(result) {//검증
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h1>사용자 추가 성공!!</h1>");
				res.write("<br/><br/><a href='/public/login.html'>로그인</a>");
				res.write("<br/><br/><a href='/public/listUser.html'>리스트</a>");
				res.end();
				
			}else {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h1>사용자 추가 실패!!</h1>");
				res.write("<br/><br/><a href='/public/login.html'>로그인</a>");
				res.write("<br/><br/><a href='/public/listUser.html'>리스트</a>");
				res.end();
				
			}
			
		});
		
	}else {
		
		res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
		res.write("<h1>데이터베이스 연결 실패!!</h1>");
		res.write("<div>데이터베이스에 연결하지 못했습니다.</div>");
		res.end();
		
	}
	
});

//사용자 리스트 함수
router.route("/process/listUser").post(function(req,res) {
	
	if(database) {
		
		//모든 사용자 검색
		UserModel.findAll(function(err,result) {//model의 스키마 메소드 부르기
			
			if(err) {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h1>사용자 리스트 조회중 에러 발생</h1>");
				res.end();
				
				return;
				
			}
			
			if(result) {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h1>사용자 리스트</h1>");
				res.write("<div><ul>");
				
				for(var i=0;i<result.length;i++) {
					
					var id = result[i]._doc.id;
					var name = result[i]._doc.name;
					var age = result[i]._doc.age;
					
					res.write("<li>#" + (i+1) + ":" + id + ", " + name + ", " + age + "</li>");
					
				}
				
				res.write("</ul></div>");
				res.write("<br/><br/><a href='/public/listUser.html'>리스트</a>");
				res.end();
				
			}else {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h1>사용자 리스트 조회 실패</h1>");
				res.end();
				
			}
			
		});
		
	}else {
		
		res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
		res.write("<h1>데이터베이스 연결 실패!!</h1>");
		res.write("<div>데이터베이스에 연결하지 못했습니다.</div>");
		res.end();
		
	}
	
});

//라우터 등록
app.use("/",router);

app.use(cookieParser());

app.use(expressSession({
	secret: "my key", //아무거나 써도 됨 - 가져가서 암호화 시킴
	resave: true, //일반적으로 true
	saveUninitialized: true //일반적으로 true - 세션 공간 초기화
}));

//404에러 페이지
var errorHandler = expressErrorHandler({
	
	static:{//404에러나면 html 찾아가라
		'404' : "./public/404.html"
	}
	
});

app.use(expressErrorHandler.httpError(404));
app.use(errorHandler);

//Express서버 시작
http.createServer(app).listen(app.get("port"),function() {
	
	console.log("Express 서버를 시작했습니다 : " + app.get("port"));
	
	connectDB(); //DB연결 함수 실행
	
});
