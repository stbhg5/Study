
//virtual 함수
//가상속성 : 비밀번호 다이렉트로 넣지 않고 vitual공간(메모리) 만들어 거기서 암호화하여 DB에 암호화한 데이터 넣음
//.get은 꺼내온 암호화 데이터 비교 위함
var mongodb = require("mongodb");
var mongoose = require("mongoose");

var database;
var UserSchema;
var UserModel;

function connectDB() {
	
	var databaseUrl = "mongodb://localhost:27017/shopping";
	
	mongoose.connect(databaseUrl);
	database = mongoose.connection;
	
	database.on("open",function() {
		
		console.log("데이터베이스 연결" + databaseUrl);
		
		createUserSchema();
		
		insertData();
		
	});
	
	//오류처리방법 2가지
	database.on("error",console.error.bind(console,"데이터베이스 연결 오류!"));
	
	database.on("disconnected",function() {
		
		console.log("데이터베이스 연결이 끊겼습니다!");
		
	});
	
}

function createUserSchema() {
	
	UserSchema = mongoose.Schema({
		
		id:{type:String, required: true, unique: true},
		name:{type:String, index:"hashed"},
		age:{type:Number, "default":20},
		created:{type:Date, index:{unique:false},"default":Date.now}
		
	});
	
	
	//{"suzi","배수지} 데이터 넘겨줄 것이다.
	//가상 속성 virtual("info") - 실제 컬렉션에 없는 것 info 가져와서 DB에 넣음
	UserSchema.virtual("info").set(function(info) {//넣을 때, 이렇게 들어가는 데이터의 대표가 info
		
		var splitted = info.split(","); //split으로 나눠 배열로 넣음
		this.id = splitted[0];
		this.name = splitted[1];
		
	})
	.get(function() {//가져올 때
		return this.id + ":" + this.name;
	});
	
	UserModel = mongoose.model("user3",UserSchema);
	
}

function insertData() {
	
	var user = new UserModel({"info":"suzi,배수지"});
	
	user.save(function(err) {
		
		if(err) throw err;
		
		console.log("사용자 추가");
		
		findAll();
		
	});
	
}

function findAll() {
	
	UserModel.find({},function(err,result) {
		
		if(err) throw err;
		
		if(result) {
			
			for(var i=0;i<result.length;i++) {
				
				console.log("id: %s, name: %s",result[i]._doc.id,result[i]._doc.name); //_doc : result객체의 결과값 빼와준다
				
			}
			
		}
		
	});
	
}

connectDB();
