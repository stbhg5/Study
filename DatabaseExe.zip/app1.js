
//http://localhost:3000/ - 페이지 오류 떠야한다
//http://localhost:3000/public/login.html - 로그인
//id:suzi,password:123
//http://localhost:3000/public/addUser.html - 회원가입

//MongoDB 연결

var express = require("express");
var http = require("http");
var path = require("path");

var serveStatic = require("serve-static"); //특정 폴더로 접근 가능하게 함
var expressErrorHandler = require("express-error-handler");
var cookieParser = require("cookie-parser");
var expressSession = require("express-session");

//몽고디비 모듈
var MongoClient = require("mongodb").MongoClient;

//익스프레스 객체 생성
var app = express(); 

//기본 포트를 app객체에 속성으로 설정
//express 객체의 메소드 (set,get,use)
app.set("port",process.env.PORT || 3000); 

//미들웨어 추가
app.use(express.urlencoded({extended: true})); 
app.use(express.json()); 

//사용할 주소 /public
app.use("/public",serveStatic(path.join(__dirname,"public")));



//데이터베이스 객체를 위한 변수
var database;

function connectDB() {
	
	//데이터베이스 연결 정보
	var databaseUrl = "mongodb://localhost:27017/shopping"; //아이피주소보다 localhost
	
	//데이터베이스 연결 - 직접 연결
	MongoClient.connect(databaseUrl,function(err,dbase) {
		
		if(err) throw err;
		
		console.log("데이터베이스에 연결되었습니다. : " + databaseUrl);
		
		database = dbase.db("shopping"); //DB
		
	});
	
}

//사용자 인증 함수
var authUser = function(database,id,password,callback) {
	
	console.log("authUser 호출");
	
	//users Collection(table) 참조
	var users = database.collection("users"); //컬렉션
	
	//id,password를 이용해서 검색
	users.find({"id":id,"password":password}).toArray(function(err,result) {//Array라서 여러개 있을 수 있다.
		
		if(err) {
			callback(err,null); //에러만 전달하고 데이터는 null전달
			return;
		}
		
		if(result.length>0) {//데이터 찾음
			
			callback(null,result); //에러 안보내고 result만 보낸다.
			
		}else {
			
			callback(null,null); //에러는 아닌데 일치사용자 없음
			
		}
		
	});
	
};

//사용자 추가 함수
var addUser = function(databas,id,pwd,name,callback) {
	
	console.log("addUser 호출");
	
	var users = database.collection("users");
	
	users.insert([{"id":id,"password":pwd,"name":name}],function(err,result) {
		
		if(err) {
			callback(err,null);
			return;
		}
		
		if(result.insertedCount>0) {
			console.log("사용자 추가");
		}else {
			console.log("사용자 추가 안됨");
		}
		
		callback(null,result);
		
	});
	
}

//라우터 객체
var router = express.Router();

//사용자 로그인 라우터
router.route("/process/login").post(function(req,res) {//id,password 보냄
	
	console.log("login 호출");
	
	var id = req.body.id;
	var pwd = req.body.pwd;
	
	//사용자 인증
	if(database) {//database 연결되어야 있어야함
		
		authUser(database, id, pwd, function(err,result) {//callback함수
			
			if(err) throw err;
			
			if(result) {//result 있으면
				
				var userName = result[0].name; //배열로 가져왔으니
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h1>로그인 성공!!</h1>");
				res.write("<div>아이디: " + id + "</div>");
				res.write("<div>이름: " + userName + "</div>");
				res.write("<br/><br/><a href='/public/login.html'>로그인</a>");
				res.end();
				
			}else {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h1>로그인 실패!!</h1>");
				res.write("<div>아이디와 패스워드를 다시 확인하세요.</div>");
				res.write("<br/><br/><a href='/public/login.html'>로그인</a>");
				res.end();
				
			}
			
		});
		
	}else {
		
		res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
		res.write("<h1>데이터베이스 연결 실패!!</h1>");
		res.write("<div>데이터베이스에 연결하지 못했습니다.</div>");
		res.end();
		
	}
	
});

//사용자 추가 라우터
router.route("/process/addUser").post(function(req,res) {
	
	console.log("addUser 호출");
	
	var id = req.body.id;
	var pwd = req.body.pwd;
	var name = req.body.name;
	
	if(database) {
		
		addUser(database, id, pwd, name, function(err,result) {
			
			if(err) throw err;
			
			if(result && result.insertedCount>0) {//검증
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h1>사용자 추가 성공!!</h1>");
				res.write("<br/><br/><a href='/public/login.html'>로그인</a>");
				res.end();
				
			}else {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h1>사용자 추가 실패!!</h1>");
				res.write("<br/><br/><a href='/public/login.html'>로그인</a>");
				res.end();
				
			}
			
		});
		
	}else {
		
		res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
		res.write("<h1>데이터베이스 연결 실패!!</h1>");
		res.write("<div>데이터베이스에 연결하지 못했습니다.</div>");
		res.end();
		
	}
	
});

//라우터 등록
app.use("/",router);

app.use(cookieParser());

app.use(expressSession({
	secret: "my key", //아무거나 써도 됨 - 가져가서 암호화 시킴
	resave: true, //일반적으로 true
	saveUninitialized: true //일반적으로 true - 세션 공간 초기화
}));

//404에러 페이지
var errorHandler = expressErrorHandler({
	
	static:{//404에러나면 html 찾아가라
		'404' : "./public/404.html"
	}
	
});

app.use(expressErrorHandler.httpError(404));
app.use(errorHandler);

//Express서버 시작
http.createServer(app).listen(app.get("port"),function() {
	
	console.log("Express 서버를 시작했습니다 : " + app.get("port"));
	
	connectDB(); //DB연결 함수 실행
	
});
