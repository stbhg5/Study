
//오라클 DB 연결 (잘 연결 안한다.), 다른 DB들도 이런식으로 연결 가능하다.
module.exports = {
	
	user	: process.env.NODE_ORACLEDB_USER || "suzi",
	password: process.env.NODE_ORACLEDB_PASSWORD || "a123",
	connectString: process.env.NODE_ORACLEDB_CONNECTIONSTRING || "localhost:1521/TestDB", //다른 DB는 여기만 바꿔주면 된다.
	externalAuth: process.env.NODE_ORACLEDB_EXTERNALAUTH ? true : false //내부인증 사용 안함
	
};
