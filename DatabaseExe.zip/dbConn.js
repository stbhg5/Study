
var oracledb = require("oracledb");
var dbConfig = require("./dbConfig.js");

oracledb.autoCommit = true;
oracledb.getConnection(
		
	{
	user:dbConfig.user,
	password:dbConfig.password,
	connectString:dbConfig.connectString
	},
	function(err,conn) {
		
		if(err) {
			console.error(err.message);
			return
		}
		
		console.log("Oracle DB연결 성공!!");
		
		var sql;
		
		//create table (오토커밋 된다)
		/*
		sql = "create table nuser(id varchar2(10),password varchar2(10),";
		sql+= "name varchar(10), age number)";
		
		conn.execute(sql);
		console.log("테이블 생성 완료!!");
		*/
		
		//insert
		/*
		sql = "insert into nuser values(:id,:pw,:name,:age)"; //자리값만 표시해서 사용자 정의
		
		//데이터 1개 넣기
		binds = [["suzi","123","수지",25]];
		
		//데이터 여러개 넣기
		binds = [
		         ["suzi1","123","수지1",25],
		         ["suzi2","123","수지2",25],
		         ["suzi3","123","수지3",25]
		         ];
		
		var result = conn.executeMany(sql,binds,{}); //{}는 함수자리
		console.log("입력 완료!!");
		*/
		
		//update
		/*
		sql = "update nuser set password=:pw,name=:name,age=:age where id=:id";
		
		conn.executeMany(sql,[["777","배수지","25","suzi"]]);
		
		console.log("수정 완료!!");
		*/
		
		//delete
		/*
		sql = "delete nuser where id=:id";
		
		conn.execute(sql,["suzi"]);
		
		console.log("삭제 완료!!");
		*/
		
		//select
		sql = "select id,password,name,age from nuser";
		
		conn.execute(sql,[],function(err,result) {
			
			if(err) {
				console.error(err.message);
				return;
			}
			
			console.log(result.rows);
			
			console.log(result.metaData); //컬럼이름
			
			doRelease(conn); //db.conn.close();
			
		});
		
	}

);

function doRelease(conn) {//DB연결 끊을 때
	
	conn.release(function(err) {
		if(err) {
			console.log(err.message);
		}
	});
	
}
