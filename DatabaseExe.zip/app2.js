
//http://localhost:3000/public/login.html - 로그인
//http://localhost:3000/public/addUser.html - 회원가입
//MongoDB 다루는 모듈

/*
Object Mapper : 자바스크립트 객체와 데이터베이스 객체를 서로 매칭해서 바꿀수있게
하는것을 오브젝트 맵퍼라고하고 가장 많이 사용하는 모듈이 몽구스모듈.

몽구스(mongoose) : 데이터베이스를 테이블이나 엑셀 시트처럼
데이터베이스를 쉽게 다룰수있는 모듈
-> 테이블에 룰 정해준다!!

Schema (String,Number,Boolean,Array,Buffer,Date,ObjectId,Mixed) - MongoDB는 자료형이 없지만 데이터타입 만듦
컬럼에 데이터 타입 규칙 정함.

어떤 문서에는 name이 있고 다른 문서에는 name이 없을 수도 있기때문에 
일정한 조건으로 적용하기가 어려움
관계형 데이터베이스처럼 조회 조건을 공통적으로 적용하기위해 만들고
그 스키마에 정해진 규칙으로 문서(열) 객체를 저장 할수있다
특히 일정한 틀에 맞는 자바스크립트 객체를 그대로 DB에 저장하거나 Schema에 의해
저장된 문서 객체를 자바스크립트 객체로 변환시킬수 있음
* 스키마를 사용하기 위해서는 model을 정의 함

[스키마객체 정의]
*스키마 타입
String,Number,Boolean,Array,Buffer,Date,ObjectId,Mixed

unique:true : 고유값 (PK)
required:true : 필수입력 (Not Null)
index:hashed : 인덱스 생성
expires:'1d' : 유효시간

UserSchema = mongoose.Schema({	//자바스크립트객체를전달
  id: {type:String,required:true,unique:true},
  password: {type:String,required:true},
  name: {type:String,index:'hashed'}, 
  age: Number,
  created: {type:Date,index:{unique:false,expires:'1d'}}	
});

*몽구스 메소드 
connect(), Schema(), model() (DB 연결, 규칙 만들기, 규칙 적용)

*model객체의 정의
UserModel = mongoose.model("users", UserSchema); //컬렉션에 스키마 적용!!

*model객체의 메소드
find, save, update, remove

*id:suzi로 찾은 데이터를 name:김수지 로 수정
UserModel.where({id:'suzi'}).update({name:'김수지'},function(err,result){})
*/

var express = require("express");
var http = require("http");
var path = require("path");

var serveStatic = require("serve-static"); //특정 폴더로 접근 가능하게 함
var expressErrorHandler = require("express-error-handler");
var cookieParser = require("cookie-parser");
var expressSession = require("express-session");
//var MongoClient = require("mongodb").MongoClient;

//mongoose 모듈
var mongoose = require("mongoose");

//익스프레스 객체 생성
var app = express(); 

//기본 포트를 app객체에 속성으로 설정
//express 객체의 메소드 (set,get,use)
app.set("port",process.env.PORT || 3000); 

//미들웨어 추가
app.use(express.urlencoded({extended: true})); 
app.use(express.json()); 

//사용할 주소 /public
app.use("/public",serveStatic(path.join(__dirname,"public")));



//데이터베이스 객체를 위한 변수
var database;

//데이터베이스 컬렉션에 적용할 스키마 객체를 위한 변수
var UserSchema; //규칙 만들기

//데이터베이스 모델 객체를 위한 변수
var UserModel; //규칙 적용

function connectDB() {
	
	//데이터베이스 연결 정보
	var databaseUrl = "mongodb://localhost:27017/shopping"; //아이피주소보다 localhost
	
	//데이터베이스 연결 - 직접 연결
	/*
	MongoClient.connect(databaseUrl,function(err,dbase) {
		
		if(err) throw err;
		
		console.log("데이터베이스에 연결되었습니다. : " + databaseUrl);
		
		database = dbase.db("shopping"); //DB
		
	});
	*/
	
	//몽구스로 데이터베이스 연결 - MongoDB연결에는 이 기능이 없다.
	mongoose.connect(databaseUrl); //DB 연결
	database = mongoose.connection; //DB연결되던 안되던 무조건 on 실행
	//모듈 내부적 emit가지고 있어서 자동으로 open이나 error,disconnected (예약어)찾아가게 한다.
	
	database.on("open",function() {//이벤트, 예약어
		
		console.log("데이터베이스에 연결되었습니다. : " + databaseUrl);
		
		//스키마 정의
		UserSchema = mongoose.Schema({
			
			id:String,
			name:String,
			password:String
			
		});
		console.log("UserSchema 정의함");
		
		//Schema를 collection에 model로 적용
		UserModel = mongoose.model("users",UserSchema);
		console.log("UserModel 정의함");
		
	});
	
	database.on("error",console.error.bind(console,"몽구스 연결 에러.."));
	
	database.on("disconnected",function() {
		
		console.log("데이터베이스 연결이 끊겼습니다");
		setInterval(connectDB(),5000); //연결이 끊기면 5초후 재연결
		
	});
	
}

//사용자 인증 함수
var authUser = function(database,id,password,callback) {
	
	console.log("authUser 호출");
	
	//users Collection(table) 참조
	//var users = database.collection("users"); //컬렉션연결 위에서 해서 필요없다
	
	//id,password를 이용해서 검색
	UserModel.find({"id":id,"password":password},function(err,result) {
		
		if(err) {
			callback(err,null); //에러만 전달하고 데이터는 null전달
			return;
		}
		
		if(result.length>0) {//데이터 찾음
			
			callback(null,result); //에러 안보내고 result만 보낸다.
			
		}else {
			
			callback(null,null); //에러는 아닌데 일치사용자 없음
			
		}
		
	});
	
};

//사용자 추가 함수
var addUser = function(databas,id,pwd,name,callback) {
	
	console.log("addUser 호출");
	
	//var users = database.collection("users");
	
	var user = new UserModel({"id":id,"password":pwd,"name":name});
	
	user.save(function(err,result) {
		
		if(err) {
			callback(err,null);
			return;
		}
		
		if(result.insertedCount>0) {
			console.log("사용자 추가");
		}else {
			console.log("사용자 추가 안됨");
		}
		
		callback(null,result);
		
	});
	
}

//라우터 객체
var router = express.Router();

//사용자 로그인 라우터
router.route("/process/login").post(function(req,res) {//id,password 보냄
	
	console.log("login 호출");
	
	var id = req.body.id;
	var pwd = req.body.pwd;
	
	//사용자 인증
	if(database) {//database 연결되어야 있어야함
		
		authUser(database, id, pwd, function(err,result) {//callback함수
			
			if(err) throw err;
			
			if(result) {//result 있으면
				
				var userName = result[0].name;
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h1>로그인 성공!!</h1>");
				res.write("<div>아이디: " + id + "</div>");
				res.write("<div>이름: " + userName + "</div>");
				res.write("<br/><br/><a href='/public/login.html'>로그인</a>");
				res.end();
				
			}else {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h1>로그인 실패!!</h1>");
				res.write("<div>아이디와 패스워드를 다시 확인하세요.</div>");
				res.write("<br/><br/><a href='/public/login.html'>로그인</a>");
				res.end();
				
			}
			
		});
		
	}else {
		
		res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
		res.write("<h1>데이터베이스 연결 실패!!</h1>");
		res.write("<div>데이터베이스에 연결하지 못했습니다.</div>");
		res.end();
		
	}
	
});

//사용자 추가 라우터
router.route("/process/addUser").post(function(req,res) {
	
	console.log("addUser 호출");
	
	var id = req.body.id;
	var pwd = req.body.pwd;
	var name = req.body.name;
	
	if(database) {
		
		addUser(database, id, pwd, name, function(err,result) {
			
			if(err) throw err;
			
			if(result) {//검증
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h1>사용자 추가 성공!!</h1>");
				res.write("<br/><br/><a href='/public/login.html'>로그인</a>");
				res.end();
				
			}else {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h1>사용자 추가 실패!!</h1>");
				res.write("<br/><br/><a href='/public/login.html'>로그인</a>");
				res.end();
				
			}
			
		});
		
	}else {
		
		res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
		res.write("<h1>데이터베이스 연결 실패!!</h1>");
		res.write("<div>데이터베이스에 연결하지 못했습니다.</div>");
		res.end();
		
	}
	
});

//라우터 등록
app.use("/",router);

app.use(cookieParser());

app.use(expressSession({
	secret: "my key", //아무거나 써도 됨 - 가져가서 암호화 시킴
	resave: true, //일반적으로 true
	saveUninitialized: true //일반적으로 true - 세션 공간 초기화
}));

//404에러 페이지
var errorHandler = expressErrorHandler({
	
	static:{//404에러나면 html 찾아가라
		'404' : "./public/404.html"
	}
	
});

app.use(expressErrorHandler.httpError(404));
app.use(errorHandler);

//Express서버 시작
http.createServer(app).listen(app.get("port"),function() {
	
	console.log("Express 서버를 시작했습니다 : " + app.get("port"));
	
	connectDB(); //DB연결 함수 실행
	
});
