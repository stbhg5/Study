package com.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.jdbc.dto.BoardDTO;

public class BoardDAO2 {
	
	private SqlSessionTemplate sessionTemplate;
	
	//������ ����
	public void setSessionTemplate(SqlSessionTemplate sessionTemplate) {
		
		this.sessionTemplate = sessionTemplate;
		
	}
	
	//num�� �ִ밪 (�ҷ��� �� ���⼭ +1)
	public int getMaxNum() {
		
		int maxNum = 0;
		
		maxNum = sessionTemplate.selectOne("com.boardMapper.maxNum");
		
		return maxNum;
		
	}
	
	
	//�Է�
	public void insertData(BoardDTO dto) {
		
		sessionTemplate.insert("com.boardMapper.insertData", dto);
		
	}
	
	
	//��ü �������� ���� - 34��
	public int getDataCount(String searchKey,String searchValue) {
		
		int totalDataCount = 0;
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("searchKey", searchKey);
		params.put("searchValue", searchValue);
		
		totalDataCount = sessionTemplate.selectOne("com.boardMapper.getDataCount", params);
		
		return totalDataCount;
		
	}
	
	
	//ǥ���� ������ (rownum ����) ������
	public List<BoardDTO> getLists(int start,int end,String searchKey,String searchValue) {//����¡�� ��ȣ�� ���۰� ��
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("start", start);
		params.put("end", end);
		params.put("searchKey", searchKey);
		params.put("searchValue", searchValue);
		
		List<BoardDTO> lists = sessionTemplate.selectList("com.boardMapper.getLists", params);
		
		return lists;
		
	}
	
	
	//num���� ��ȸ�� �� ���� ������
	public BoardDTO getReadData(int num) {
		
		BoardDTO dto = sessionTemplate.selectOne("com.boardMapper.getReadData", num);
		
		return dto;
		
	}
	
	
	//��ȸ�� ����
	public void updateHitCount(int num) {
		
		sessionTemplate.update("com.boardMapper.updateHitCount", num);
		
	}
	
	
	//����
	public void updateData(BoardDTO dto) {
		
		sessionTemplate.update("com.boardMapper.updateData", dto);
		
	}
	
	
	//����
	public void deleteData(int num) {
		
		sessionTemplate.delete("com.boardMapper.deleteData", num);
		
	}
	
}
