
//집 IP : 175.192.255.145
//학원컴퓨터 IP : 192.168.63.30
//http://localhost:3000/public1/chat1.html - 소켓 서버 연결
//http://localhost:3000/public1/chat2.html - Echo 기능
//http://localhost:3000/public1/chat3.html - 일대일 채팅

//http://localhost:3000/ - index
//http://localhost:3000/public1/login.html - 로그인
//http://localhost:3000/public1/addUser.html - 회원가입
//http://localhost:3000/public1/listUser.html - 리스트
//http://localhost:3000/public1/listUserResp.html - 불러온 리스트
//http://localhost:3000/public1/login.html1 - 에러

/*
채팅 서버

- Web Socket : 웹 서버로 소켓을 연결한 후 데이터를 주고 받을 수 있도록 HTML5 표준
웹 브라우저가 이 기능을 지원하지 않아도 Web Socket을 사용할 수 있게 만든것이
Socket.io 모듈이다.

- cors 모듈 : Ajax의 XMLHttpRequest는 보안 문제로 웹 사이트를 제공하는 서버 외에
다른 서버에는 접속할 수 없는데 cors(Cross-Origin Resource Sharing)를 사용하면
제약이 풀림 - 클라이언트에서 ajax로 요청시 다중서버접속을 지원
*/

var express = require("express");
var http = require("http");
var path = require("path");

var serveStatic = require("serve-static"); //특정 폴더로 접근 가능하게 함
var expressErrorHandler = require("express-error-handler");
var cookieParser = require("cookie-parser");
var expressSession = require("express-session");

//var mongoose = require("mongoose");

var passport = require("passport");
var flash = require("connect-flash"); //메세지 전달

//Socket.io 모듈
//var socketio = require("socket.io")(app);

//cors 모듈 : 클라이언트에서 ajax로 요청시 다중서버접속을 지원
var cors = require("cors");

//config.js 모듈
var config = require("./config/config");

//database.js 모듈
var database = require("./database/database");

//routerLoader.js 모듈
var routerLoader = require("./router/routerLoader");

//익스프레스 객체 생성
var app = express(); 

//기본 포트를 app객체에 속성으로 설정
//express 객체의 메소드 (set,get,use)
app.set("port",process.env.PORT || config.serverPort);
//app.set("port",process.env.PORT || 3000);

//뷰엔진 설정
app.set("views",__dirname + "/views"); //views는 문법이다.
app.set("view engine","ejs");
console.log("뷰 엔진은 ejs로 설정되었습니다.");

//app.set("view engine","jade");
//console.log("뷰 엔진은 jade로 설정되었습니다.");

//미들웨어 추가
app.use(express.urlencoded({extended: true})); 
app.use(express.json());

//사용할 주소 /public
app.use("/public1",serveStatic(path.join(__dirname,"public1")));
/*
//라우터 객체생성
var router = express.Router();
routerLoader.init(app,router);
*/

//cors추가
app.use(cors());

app.use(cookieParser());

app.use(expressSession({
	secret: "my key", //아무거나 써도 됨 - 가져가서 암호화 시킴
	resave: true, //일반적으로 true
	saveUninitialized: true //일반적으로 true - 세션 공간 초기화
}));

//Passport 사용 : 반드시 세션 아래에 코딩
//Passport의 두개의 함수를 호출했을 때 반환하는 객체를 미들웨어로 등록
app.use(passport.initialize());
app.use(passport.session());
app.use(flash());

//라우터 객체생성 : 순서 무조건 app.use(flash());다음에 두기
var router = express.Router();
routerLoader.init(app,router);

//Passport 설정
var configPassport = require("./passport/passport");
configPassport(app,passport);

//Passport 라우팅 설정
var userPassport = require("./router/userPassport");
userPassport(router,passport);



//404에러 페이지
var errorHandler = expressErrorHandler({
	
	static:{//404에러나면 html 찾아가라
		'404' : "./public/404.html"
	}
	
});

app.use(expressErrorHandler.httpError(404));
app.use(errorHandler);

//에러가 나도 서버가 종료되는 것을 방지
process.on("uncaughException",function(err) {
	
	console.log("서버프로세스 종료하지 않고 유지함.");
	
});

//Express서버 시작
var host = "localhost";

var server = http.createServer(app).listen(app.get("port"),host,function() {
	
	console.log("Express 서버를 시작했습니다 : " + app.get("port"));
	
	//connectDB(); //DB연결 함수 실행
	
	//데이터베이스 초기화
	database.init(app,config); //app은 express 서버, ★config는 config.js
	
});

//클라이언트가 보내온 요청을 처리하기 위해 socket의 listen() 메소드를 호출
//socket의 객체가 들어있는 io는 클라이언트가 접속하거나 데이터를 전송했을 때 이벤트 발생 시킴
//var io = socketio.listen(server); //위에서 Socket.io 모듈 만들었을 때
//var io = socketio.attach(server);

//Socket.io 모듈
var io = require("socket.io")(server);

var loginID = {};

//클라이언트가 웹socket으로 연결했을 때 발생하는 기본 이벤트(connection)
//socket객체 안에는 접속한 클라이언트의 ip,port번호가 들어있음.
io.sockets.on("connection",function(socket) {
	
	console.log("connection Info: ",socket.request.connection._peername); //연결 정보
	//console.log("connection Info: " + socket.request.connection._peername); //+로 하면 Object 뜸, 자신을 인식 못함
	
	//socket.remoteAddress = socket.request.connection._peername.address; //ip
	//socket.remotePort = socket.request.connection._peername.port; //port
	
	//socket.emit("login",output);에서 보낸 데이터 처리
	socket.on("login",function(login) {
		
		console.log("login 호출");
		
		//소켓id를 추가
		//로그인ID -> 소켓ID
		loginID[login.id] = socket.id;//login.id속성 만드는 자바스크립트 문법
		
		console.log("접속한 소켓 ID: " + socket.id);
		
		//클라이언트 login에서 받은 데이터를 socket객체의 속성으로 추가
		socket.loginId = login.id; //넘어온 id
		socket.loginAlias = login.alias; //넘어온 alias
		
		//응답메세지 전송
		//sendResponse(socket,command,code,message)
		sendResponse(socket,"login","200",socket.loginId + "(" + socket.loginAlias + ")가 로그인 되었습니다.");
		
		console.log("접속한 클라이언트 인원 수: " + Object.keys(loginID).length);
		
	});
	
	//로그아웃
	socket.on("logout",function (logout) {
		
		sendResponse(socket,"logout","444",logout.id + "가 로그아웃 되었습니다.");
		
		delete loginID[logout.id]; //아이디 지워줘야함
		
		console.log("접속한 클라이언트 인원 수: " + Object.keys(loginID).length);
		
	});
	
	//2. 메세지 받기(on 메소드)
	socket.on("message",function(message) {
		
		console.log("message 받음");
		
		//나를 포함한 모든 클라이언트에게 메세지 전달
		if(message.receiver=="ALL") {//모두에게
			
			console.log("모든 사용자에게 message를 전송합니다.");
			
			io.sockets.emit("message",message); //모든 클라이언트에게 메세지가 다시 그대로 넘어감
			
		}else {//모두가 아닌 일대일 메시지 - !ALL
			
			if(loginID[message.receiver]) {
				
				//io.sockets.connected(loginID[message.receiver]).emit("message",message); //2.0 버전
				io.to(loginID[message.receiver]).emit("message",message); //3.0 버전
				
				sendResponse(socket,"message","200",message.receiver + "에게 메세지를 전송했습니다.");
				
			}else {//로그인 하지 않은 경우
				
				sendResponse(socket,"login","404",message.receiver + "상대방의 로그인 ID를 찾을 수 없습니다.");
				
			}
			
		}
		
	});
	
});

function sendResponse(socket,command,code,message) {
	
	var returnMessage = {command:command,code:code,message:message};
	
	socket.emit("response",returnMessage);
	
}
