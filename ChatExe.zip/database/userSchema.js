
//crypto 모듈
var crypto = require("crypto");

var Schema = {};

Schema.createSchema = function(mongoose) {
	
	//스키마 정의
	UserSchema = mongoose.Schema({
		
		email:{type:String, required: true, unique: true},
		hashed_password:{type:String, required: true},
		salt:{type:String, required: true},
		name:{type:String, index:"hashed"},
		created:{type:Date, index:{unique:false},"default":Date.now}
		
	});
	
	//virtual 속성
	UserSchema.virtual("password")
	.set(function(password) {
		
		this._password = password; //_구분위해 붙임. 안 붙여도 됨. //사용자가 입력한 패스워드 - 버림
		this.salt = this.makeSalt(); //key값 생성
		this.hashed_password = this.encryptPassword(password); //암호화된 패스워드
		
	})
	.get(function() {
		return this._password;
	});
	
	//스키마에 method로 추가
	UserSchema.method("encryptPassword",function(inputPwd,inSalt) {//사용자입력비번,salt
		
		if(inSalt) {
			return crypto.createHmac("sha1",inSalt).update(inputPwd).digest("hex"); //쉬바 : 암호화 하는 기술 (sha1,sha2,sha3) 3가지
		}else {
			return crypto.createHmac("sha1",this.salt).update(inputPwd).digest("hex"); //this.salt는 내부적으로 만든것
		}
		
	});
	
	UserSchema.method("makeSalt",function() {//데이터 비교 위해 보존해야 한다 - DB저장
		
		console.log("date: " + new Date().valueOf()); //날짜를 숫자로 보여줌 = 1572856039737
		console.log("math: " + Math.random()); //랜덤숫자 = 0.8524552533483953
		//위 두 값을 만들어 salt 만든다
		
		//round : 소숫점 아래 버림
		return Math.round((new Date().valueOf() * Math.random())) + ""; //""해주면 문자로 변환된다.(숫자 + 문자 = 문자) //사용자 정의
		
	});
	
	//인증 메소드(입력된 비밀번호와 비교작업)
	UserSchema.method("authenticate",function(inputPwd,inSalt,hashed_password) {//inputPwd+inSalt로 암호화 vs 이미 암호화된 hashed_password - 비교
		
		if(inSalt) {
			
			console.log("inputPwd: " + inputPwd);
			console.log("encryptPassword: " + this.encryptPassword(inputPwd,inSalt));
			console.log("hashed_password: " + hashed_password);
			
			return this.encryptPassword(inputPwd,inSalt)===hashed_password;
			
		}else {
			
			console.log("inputPwd: " + inputPwd);
			console.log("encryptPassword: " + this.encryptPassword(inputPwd));
			console.log("hashed_password: " + hashed_password);
			
			return this.encryptPassword(inputPwd)===this.hashed_password;
			
		}
		
	});
	
	
	//스키마 객체에 메소드 추가 (static(), method() : 2가지 방법)
	
	//스키마에 static으로 findById 메소드 추가(로그인에서 사용)
	UserSchema.static("findByEmail",function(email,callback) {
		return this.find({email:email},callback); //db에서 id로 검색
	});
	
	//스키마에 static으로 findAll 메소드 추가(전체데이터 가져오기)
	UserSchema.static("findAll",function(callback) {
		return this.find({}, callback); //검색조건 없음
	});
	
	console.log("UserSchema 정의함");
	
	return UserSchema;
	
}

module.exports = Schema; //밖에서 사용 가능하도록
