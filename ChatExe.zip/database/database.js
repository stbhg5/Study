
var mongoose = require("mongoose");

//database 객체에 db,schema,model 모두 추가
var database = {};

database.init = function(app,config) {//도화선 역할
	
	connect(app,config);
	
}

//데이터베이스에 연결하고 응답객체의 속성으로 db객체 추가
function connect(app,config) {
	
	console.log("connect 호출");
	
	//데이터베이스 연결
	mongoose.connect(config.dbUrl); //dbUrl: "mongodb://localhost:27017/shopping"
	database = mongoose.connection;
	
	database.on("open",function() {
		
		console.log("데이터베이스에 연결되었습니다.: " + config.dbUrl);
		
		createSchema(app,config); //config에 위치있다.
		
	});
	
	database.on("error",console.error.bind(console,"몽구스 연결 에러.."));
	
	database.on("disconnected",function() {
		
		console.log("데이터베이스 연결이 끊겼습니다");
		setInterval(connectDB,5000); //연결이 끊기면 5초후 재연결
		
	});
	
};

function createSchema(app,config) {
	
	var schemaLen = config.dbSchemas.length; //점점 늘어난다
	
	for(var i=0;i<schemaLen;i++) {
		
		var curItem = config.dbSchemas[i]; //간단히 변수처리로 정리
		
		//모듈파일에서 모듈을 호출한 후 createSchema()함수 호출
		var curSchema = require(curItem.file).createSchema(mongoose); //userSchema.js의 createSchema메소드 읽음
		
		//모델 정의
		var curModel = mongoose.model(curItem.collection,curSchema); //config.dbSchemas[0]의 collection
		
		//database객체에 스키마와 모델을 속성으로 추가
		database[curItem.schemaName] = curSchema; //변수 만든것 UserSchema에 위 만든 curSchema 들어감
		database[curItem.modelName] = curModel; //변수 만든것 UserModel에 위 만든 curModel 들어감
		
	}
	
	//app.set("port",process.env.PORT || 3000); 이 코딩처럼
	app.set("database",database); //db + Schema + Model
	
}

module.exports = database;
