package com.exe.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class MyAroundAdvice {
	
	@Around("execution(* com..aop.*.*(..))")
	public Object aroundMethodCall(ProceedingJoinPoint jointPoint) {
		
		Object result = null;
		
		try {
			
			System.out.println("JointPoint ������(Around Before)");
			
			result = jointPoint.proceed(); //�޼ҵ� ����
			
			System.out.println("JointPoint ������(Around After)");
			
		} catch (Throwable e) {//ȸ�峪��.. �����ϰ� Throwable�� ó��
			
		}
		
		return result;
		
	}
	
}
