
//집 IP : 175.192.255.145
//학원컴퓨터 IP : 192.168.63.30
//http://localhost:3000/public/addCoffeeShop.html

/*
위치기반 서비스 서버 만들기 (LBS : Location Based Service)

특정 위치의 정보를 제공하고 조회하는 방법을 MongoDB에서 제공

위치정보는 경도와 위도를 사용
위치정보를 저장하거나 조회할 때 공간 인덱싱(Spatial Indexing)이란 방법으로
위도의 좌표를 인덱스로 만들어 조회 속도를 높임.
MongoDB에서는 GeoSpatial Indexing이라고 함.

조회방법
1.near
2.within
3.circle

위치데이터의 종류
1. Point : 현재 위치나 스타벅스 위치같은 특정한 지점
2. LineString : 도로와 같은 이어진 위치 
3. Polygon : 역삼동, 강남역 같은 위치
*/

var express = require("express");
var http = require("http");
var path = require("path");

var serveStatic = require("serve-static"); //특정 폴더로 접근 가능하게 함
var expressErrorHandler = require("express-error-handler");
var cookieParser = require("cookie-parser");
var expressSession = require("express-session");

//var mongoose = require("mongoose");

var passport = require("passport");
var flash = require("connect-flash"); //메세지 전달

//user.js 모듈
//var user = require("./router/user"); //.js 안 붙여도 된다

//config.js 모듈
var config = require("./config/config");

//database.js 모듈
var database = require("./database/database");

//routerLoader.js 모듈
var routerLoader = require("./router/routerLoader");

//익스프레스 객체 생성
var app = express(); 

//기본 포트를 app객체에 속성으로 설정
//express 객체의 메소드 (set,get,use)
app.set("port",process.env.PORT || config.serverPort);
//app.set("port",process.env.PORT || 3000);

//뷰엔진 설정
app.set("views",__dirname + "/views"); //views는 문법이다.
app.set("view engine","ejs");
console.log("뷰 엔진은 ejs로 설정되었습니다.");

//app.set("view engine","jade");
//console.log("뷰 엔진은 jade로 설정되었습니다.");

//미들웨어 추가
app.use(express.urlencoded({extended: true})); 
app.use(express.json());

//사용할 주소 /public
app.use("/public",serveStatic(path.join(__dirname,"public")));
/*
//라우터 객체생성
var router = express.Router();
routerLoader.init(app,router);
*/
app.use(cookieParser());

app.use(expressSession({
	secret: "my key", //아무거나 써도 됨 - 가져가서 암호화 시킴
	resave: true, //일반적으로 true
	saveUninitialized: true //일반적으로 true - 세션 공간 초기화
}));

//Passport 사용 : 반드시 세션 아래에 코딩
//Passport의 두개의 함수를 호출했을 때 반환하는 객체를 미들웨어로 등록
app.use(passport.initialize());
app.use(passport.session());
app.use(flash());

//라우터 객체생성 : 순서 무조건 app.use(flash());다음에 두기
var router = express.Router();
routerLoader.init(app,router);

//Passport 설정
var configPassport = require("./passport/passport");
configPassport(app,passport);

//Passport 라우팅 설정
var userPassport = require("./router/userPassport");
userPassport(router,passport);

//404에러 페이지
var errorHandler = expressErrorHandler({
	
	static:{//404에러나면 html 찾아가라
		'404' : "./public/404.html"
	}
	
});

app.use(expressErrorHandler.httpError(404));
app.use(errorHandler);

//에러가 나도 서버가 종료되는 것을 방지
process.on("uncaughException",function(err) {
	
	console.log("서버프로세스 종료하지 않고 유지함.");
	
});

//Express서버 시작
var host = "localhost"; //IP (CMD ipconfig) - 바뀐다, localhost로 하면 핸드폰 접속 불가
//var host = "192.168.63.30"; //학원컴퓨터

http.createServer(app).listen(app.get("port"),host,function() {
	
	console.log("Express 서버를 시작했습니다 : " + app.get("port"));
	
	//connectDB(); //DB연결 함수 실행
	
	//데이터베이스 초기화
	database.init(app,config); //app은 express 서버, ★config는 config.js
	
});
