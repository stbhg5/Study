
var add = function (req,res) {
	
	console.log("add 호출");
	
	//param은 post/get 가리지 않음 - var name = req.body("name");는 post 방식
	var name = req.param("name");
	var address = req.param("address");
	var tel = req.param("tel");
	var longitude = req.param("longitude");
	var latitude = req.param("latitude");
	
	var database = req.app.get("database");
	
	if(database) {
		
		addCoffeeShop(database,name,address,tel,longitude,latitude,function(err,result) {
			
			if(err) {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
				res.write("<h2>스타벅스 추가 중 에러 발생</h2>");
				res.end();
				
				return;
				
			}
			
			if(result) {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
				res.write("<h2>스타벅스 추가 성공</h2>");
				res.end();
				
			}else {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
				res.write("<h2>스타벅스 추가 실패</h2>");
				res.end();
				
			}
			
		});
		
	}else {
		
		res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
		res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
		res.write("<h2>데이터베이스 연결 실패</h2>");
		res.end();
		
	}
	
};

//추가 함수
var addCoffeeShop = function(database,name,address,tel,longitude,latitude,callback) {
	
	var coffeeshop = new database.CoffeeShopModel(
			{name:name,address:address,tel:tel,
				geometry: 
				{
					type:"Point",
					coordinates:[longitude,latitude]
				}
			}
	);
	
	coffeeshop.save(function(err) {
		
		if(err) {
			callback(err,null);
			return;
		}
		
		callback(null,coffeeshop);
		
	});
	
}

module.exports.add = add;
