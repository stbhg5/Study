
var add = function (req,res) {
	
	console.log("add 호출");
	
	//param은 post/get 가리지 않음 - var name = req.body("name");는 post 방식
	var name = req.param("name");
	var address = req.param("address");
	var tel = req.param("tel");
	var longitude = req.param("longitude");
	var latitude = req.param("latitude");
	
	var database = req.app.get("database");
	
	if(database) {
		
		addCoffeeShop(database,name,address,tel,longitude,latitude,function(err,result) {
			
			if(err) {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
				res.write("<h2>스타벅스 추가 중 에러 발생</h2>");
				res.end();
				
				return;
				
			}
			
			if(result) {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
				res.write("<h2>스타벅스 추가 성공</h2>");
				res.end();
				
			}else {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
				res.write("<h2>스타벅스 추가 실패</h2>");
				res.end();
				
			}
			
		});
		
	}else {
		
		res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
		res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
		res.write("<h2>데이터베이스 연결 실패</h2>");
		res.end();
		
	}
	
};

//추가 함수
var addCoffeeShop = function(database,name,address,tel,longitude,latitude,callback) {
	
	var coffeeshop = new database.CoffeeShopModel(
			{name:name,address:address,tel:tel,
				geometry: 
				{
					type:"Point",
					coordinates:[longitude,latitude]
				}
			}
	);
	
	coffeeshop.save(function(err) {
		
		if(err) {
			callback(err,null);
			return;
		}
		
		callback(null,coffeeshop);
		
	});
	
}

//리스트
var list = function(req,res) {
	
	console.log("list 호출");
	
	var database = req.app.get("database");
	
	if(database) {
		
		//모든 데이터 검색
		database.CoffeeShopModel.findAll(function(err,result) {
			
			if(err) {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
				res.write("<h2>스타벅스 조회 중 에러 발생</h2>");
				res.end();
				
				return;
				
			}
			
			if(result) {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
				res.write("<h2>스타벅스 리스트</h2>");
				res.write("<div><ul>");
				
				for(var i=0;i<result.length;i++) {
					
					var name = result[i]._doc.name;
					var address = result[i]._doc.address;
					var tel = result[i]._doc.tel;
					var longitude = result[i]._doc.geometry.coordinates[0]; //경도
					var latitude = result[i]._doc.geometry.coordinates[1]; //위도
					
					res.write("<li>#" + (i+1) + " : " + name + ", " + address + ", " + tel + ", " +
							longitude + ", " + latitude + "</li>");
					
				}
				
				res.write("</ul></div>");
				res.end();
				
			}else {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
				res.write("<h2>스타벅스 조회 실패</h2>");
				res.end();
				
			}
			
		});
		
	}else {
		
		res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
		res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
		res.write("<h2>데이터베이스 연결 실패</h2>");
		res.end();
		
	}
	
}

//가장 가까운 스타벅스
var findNear = function(req,res) {
	
	console.log("findNear 호출");
	
	var maxDistance = 100; //10:100m, 100:1km, 250:2.5km, 300:3km
	
	/*
	GPS에서 거리 계산법
	경도 * 100000.0 * 1.110 = 1의 자리가 1m
	위도 * 100000.0 * 0.084 = 1의 자리가 1m
	
	교육원 좌표 : 환산값
	127.031808 : 14100530
	37.498856 : 314990
	
	국기원사거리 좌표 : 환산값
	127.031633 : 14100511
	37.499726 : 314997
	
	정확도는 +- 20~30m
	14100530 - 14100511 = 19m
	314990 - 314997 = -7(1m)
	*/
	
	var longitude = req.body.longitude;
	var latitude = req.body.latitude;
	
	var database = req.app.get("database");
	
	if(database) {
		
		//모든 데이터 검색
		database.CoffeeShopModel.findNear(longitude,latitude,maxDistance,function(err,result) {
			
			if(err) {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
				res.write("<h2>스타벅스 조회 중 에러 발생</h2>");
				res.end();
				
				return;
				
			}
			
			if(result) {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
				res.write("<h2>가까운 스타벅스 리스트</h2>");
				res.write("<div><ul>");
				
				for(var i=0;i<result.length;i++) {
					
					var name = result[i]._doc.name;
					var address = result[i]._doc.address;
					var tel = result[i]._doc.tel;
					var longitude = result[i]._doc.geometry.coordinates[0]; //경도
					var latitude = result[i]._doc.geometry.coordinates[1]; //위도
					
					res.write("<li>#" + (i+1) + " : " + name + ", " + address + ", " + tel + ", " +
							longitude + ", " + latitude + "</li>");
					
				}
				
				res.write("</ul></div>");
				res.end();
				
			}else {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
				res.write("<h2>스타벅스 조회 실패</h2>");
				res.end();
				
			}
			
		});
		
	}else {
		
		res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
		res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
		res.write("<h2>데이터베이스 연결 실패</h2>");
		res.end();
		
	}
	
}

//범위 내 스타벅스
var findWithin = function(req,res) {
	
	console.log("findWithin 호출");
	
	var topLeftLongitude = req.body.topleft_longitude;
	var topLeftLatitude = req.body.topleft_latitude;
	
	var bottomRightLongitude = req.body.bottomright_longitude;
	var bottomRightLatitude = req.body.bottomright_latitude;
	
	var database = req.app.get("database");
	
	if(database) {
		
		//모든 데이터 검색
		database.CoffeeShopModel.findWithin(topLeftLongitude,topLeftLatitude,
				bottomRightLongitude,bottomRightLatitude,function(err,result) {
			
			if(err) {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
				res.write("<h2>스타벅스 조회 중 에러 발생</h2>");
				res.end();
				
				return;
				
			}
			
			if(result) {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
				res.write("<h2>가까운 스타벅스 리스트</h2>");
				res.write("<div><ul>");
				
				for(var i=0;i<result.length;i++) {
					
					var name = result[i]._doc.name;
					var address = result[i]._doc.address;
					var tel = result[i]._doc.tel;
					var longitude = result[i]._doc.geometry.coordinates[0]; //경도
					var latitude = result[i]._doc.geometry.coordinates[1]; //위도
					
					res.write("<li>#" + (i+1) + " : " + name + ", " + address + ", " + tel + ", " +
							longitude + ", " + latitude + "</li>");
					
				}
				
				res.write("</ul></div>");
				res.end();
				
			}else {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
				res.write("<h2>스타벅스 조회 실패</h2>");
				res.end();
				
			}
			
		});
		
	}else {
		
		res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
		res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
		res.write("<h2>데이터베이스 연결 실패</h2>");
		res.end();
		
	}
	
}

//반경 내 스타벅스
var findCircle = function(req,res) {
	
	console.log("findCircle 호출");
	
	var centerLongitude = req.body.center_longitude;
	var centerLatitude = req.body.center_latitude;
	var radius = req.body.radius;
	
	var database = req.app.get("database");
	
	if(database) {
		
		//모든 데이터 검색
		database.CoffeeShopModel.findCircle(centerLongitude,centerLatitude,radius,function(err,result) {
			
			if(err) {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
				res.write("<h2>스타벅스 조회 중 에러 발생</h2>");
				res.end();
				
				return;
				
			}
			
			if(result) {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
				res.write("<h2>가까운 스타벅스 리스트</h2>");
				res.write("<div><ul>");
				
				for(var i=0;i<result.length;i++) {
					
					var name = result[i]._doc.name;
					var address = result[i]._doc.address;
					var tel = result[i]._doc.tel;
					var longitude = result[i]._doc.geometry.coordinates[0]; //경도
					var latitude = result[i]._doc.geometry.coordinates[1]; //위도
					
					res.write("<li>#" + (i+1) + " : " + name + ", " + address + ", " + tel + ", " +
							longitude + ", " + latitude + "</li>");
					
				}
				
				res.write("</ul></div>");
				res.end();
				
			}else {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
				res.write("<h2>스타벅스 조회 실패</h2>");
				res.end();
				
			}
			
		});
		
	}else {
		
		res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
		res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
		res.write("<h2>데이터베이스 연결 실패</h2>");
		res.end();
		
	}
	
}

//가장 가까운 스타벅스 지도
var findNear2 = function(req,res) {
	
	console.log("findNear2 호출");
	
	var maxDistance = 100; //10:100m, 100:1km, 250:2.5km, 300:3km
	
	var longitude = req.body.longitude;
	var latitude = req.body.latitude;
	
	var database = req.app.get("database");
	
	if(database) {
		
		//모든 데이터 검색
		database.CoffeeShopModel.findNear(longitude,latitude,maxDistance,function(err,result) {
			
			if(err) {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
				res.write("<h2>스타벅스 조회 중 에러 발생</h2>");
				res.end();
				
				return;
				
			}
			
			if(result) {
				
				if(result.length>0) {//배열식
					
					res.render("findNear.ejs",
							{result:result[0]._doc,
							longitude:longitude,
							latitude:latitude});
					
				}else {
					
					res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
					res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
					res.write("<h2>가까운 스타벅스 조회 실패</h2>");
					res.end();
					
				}
				
			}else {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
				res.write("<h2>스타벅스 조회 실패</h2>");
				res.end();
				
			}
			
		});
		
	}else {
		
		res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
		res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'>");
		res.write("<h2>데이터베이스 연결 실패</h2>");
		res.end();
		
	}
	
}

module.exports.add = add;
module.exports.list = list;
module.exports.findNear = findNear;
module.exports.findWithin = findWithin;
module.exports.findCircle = findCircle;

module.exports.findNear2 = findNear2;
