
var routerLoader = {};

var config = require("../config/config"); //나가는 코딩 ..

routerLoader.init = function(app,router) {
	
	console.log("routerLoader 호출");
	
	return initRouters(app,router);
	
};

//routerInfo에 있는 라우팅의 정보 처리
function initRouters(app,router) {
	
	var infoLen = config.routerInfo.length; //3개
	
	for(var i=0;i<infoLen;i++) {
		
		var curItem = config.routerInfo[i];
		
		//모듈 호출
		var curModule = require(curItem.file); //user.js //많으면 바뀔 수 있다.
		
		//라우팅 처리
		if(curItem.type=="get") {
			
			//router.route("/process/login").get(user.login);
			router.route(curItem.path).get(curModule[curItem.method]);
			
		}else if(curItem.type=="post") {
			
			router.route(curItem.path).post(curModule[curItem.method]);
			
		}else {//일반적으로 post 쓰니
			
			router.route(curItem.path).post(curModule[curItem.method]);
			
		}
		
		console.log("라우트 모듈 설정: " + curItem.method);
		
	}
	
	//미들웨어에 라우터 등록(use)
	app.use("/",router);
	
};

module.exports = routerLoader;
