
var Schema = {}

Schema.createSchema = function(mongoose) {
	
	var CoffeeShopSchema = mongoose.Schema({
		
		name:{type:String,index:"hashed"},
		address:{type:String},
		tel:{type:String},
		geometry:{
			//경도와 위도를 저장
			type:{type:String,"default":"Point"},
			coordinates:[{type:"Number"}]
		},
		created:{type:Date,index:{unique:false},"default":Date.now}
		
	});
	
	//geometry에 공간인덱싱을 만들면 속도가 빨라짐
	//위치좌표는 2d sphere타입
	CoffeeShopSchema.index({geometry:"2dsphere"});
	
	//모든 스타벅스 조회
	CoffeeShopSchema.static("findAll",function(callback) {
		
		return this.find({},callback); //조건X, callback
		
	});
	
	console.log("CoffeeShopSchema 정의");
	
	return CoffeeShopSchema;
	
}

module.exports = Schema;
