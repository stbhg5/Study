
var Schema = {}

Schema.createSchema = function(mongoose) {
	
	var CoffeeShopSchema = mongoose.Schema({
		
		name:{type:String,index:"hashed"},
		address:{type:String},
		tel:{type:String},
		geometry:{
			//경도와 위도를 저장
			type:{type:String,"default":"Point"},
			coordinates:[{type:"Number"}]
		},
		created:{type:Date,index:{unique:false},"default":Date.now}
		
	});
	
	//geometry에 공간인덱싱을 만들면 속도가 빨라짐
	//위치좌표는 2d sphere타입
	CoffeeShopSchema.index({geometry:"2dsphere"});
	
	//모든 스타벅스 조회
	CoffeeShopSchema.static("findAll",function(callback) {
		
		return this.find({},callback); //조건X, callback
		
	});
	
	//가장 가까운 스타벅스 조회
	//maxDistance : 기준점으로부터 최대 거리
	CoffeeShopSchema.static("findNear",function(longitude,latitude,maxDistance,callback) {
		
		console.log("findNear 호출");
		
		this.find().where("geometry").near({center:{type:"Point",
			coordinates:[parseFloat(longitude),parseFloat(latitude)]},
			maxDistance:maxDistance}).limit(1).exec(callback); //limit(1)은 1개만 찾아라
		
	});
	
	//범위 내 스타벅스 조회
	CoffeeShopSchema.static("findWithin",function(topleft_longitude,topleft_latitude,
			bottomright_longitude,bottomright_latitude,callback) {
		
		console.log("findWithin 호출");
		
		this.find().where("geometry").within({box:[[parseFloat(topleft_longitude),parseFloat(topleft_latitude)],
		                                           [parseFloat(bottomright_longitude),parseFloat(bottomright_latitude)]]}).exec(callback);
		
	});
	
	//반경 내 스타벅스 조회
	CoffeeShopSchema.static("findCircle",function(center_longitude,center_latitude,radius,callback) {//radius : 반지름
		
		console.log("findCircle 호출");
		//1/6371 : 1km
		this.find().where("geometry").within({center:[parseFloat(center_longitude),parseFloat(center_latitude)], //circle도 된다.
		                                      radius:parseFloat(radius/6371000),
		                                      unique:true,spherical:true}).exec(callback);
		
	});
	
	console.log("CoffeeShopSchema 정의");
	
	return CoffeeShopSchema;
	
}

module.exports = Schema;
