package com.imageTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.Preparable;
import com.util.FileManager;
import com.util.MyUtil;
import com.util.dao.CommonDAO;
import com.util.dao.CommonDAOImpl;

public class ImageTestAction extends ActionSupport implements Preparable,ModelDriven<ImageTestDTO> {
	
	private static final long serialVersionUID = 1L;
	
	private ImageTestDTO dto;
	
	public ImageTestDTO getDto() {
		return dto;
	}

	@Override
	public ImageTestDTO getModel() {
		return dto;
	}

	@Override
	public void prepare() throws Exception {
		dto = new ImageTestDTO();
	}
	
	
	public String login() throws Exception {//http://localhost:8080/struts2/imageTest/login.action
		
		if(dto==null||dto.getMode()==null||dto.getMode().equals("")) {
			return INPUT;
		}
		
		CommonDAO dao = CommonDAOImpl.getInstance();
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		
		String userId = dto.getUserId();
		String userPwd = dto.getUserPwd();
		
		dto = (ImageTestDTO)dao.getReadData("imageTest.readLoginData", userId);
		
		if(dto==null || (!dto.getUserPwd().equals(userPwd))) {//���̵� ���ų�, ���̵�� �´µ� ��й�ȣ�� dto���� �����°Ͱ� ����ڰ� �Է��Ѱ� ��ġ���� ������
			
			request.setAttribute("message", "���̵� �Ǵ� �н����带 ��Ȯ�� �Է��ϼ���.");
			return INPUT;
			
		}
		
		CustomInfo info = new CustomInfo();
		
		info.setUserId(dto.getUserId());
		info.setUserName(dto.getUserName());
		
		session.setAttribute("customInfo", info);
		
		return SUCCESS;
		
	}
	
	public String loginJoin() throws Exception {
		
		if(dto==null||dto.getMode()==null||dto.getMode().equals("")) {
			return INPUT;
		}
		
		CommonDAO dao = CommonDAOImpl.getInstance();
		
		dao.insertData("imageTest.insertLoginData", dto);
		
		return SUCCESS;
		
	}
	
	public String logout() throws Exception {
		
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		
		//���������� �ڱⰡ �� ������ ���� �α׾ƿ��ϸ� ���� �α׾ƿ� �ȴ�.
		session.removeAttribute("customInfo"); //���� �� ������ ����
		session.invalidate(); //���� ����
		
		return SUCCESS;
		
	}
	
	public String created() throws Exception {//http://localhost:8080/struts2/imageTest/created.action
		
		if(dto==null||dto.getMode()==null||dto.getMode().equals("")) {
			return INPUT;
		}
		
		CommonDAO dao = CommonDAOImpl.getInstance();
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		
		String root = session.getServletContext().getRealPath("/");
		String savePath = root + "pds" + File.separator + "image";
		
		saveFileName = FileManager.doFileUpload(dto.getUpload(), dto.getUploadFileName(), savePath); //��������,�����̸�,���ϰ��
		
		originalFileName = dto.getUploadFileName(); //���� �̸� ������, �ٿ�ε忡�� ���� ���ؼ�
		
		if(saveFileName!=null) {
			
			int maxNum = dao.getIntValue("imageTest.maxNum");
			dto.setNum(maxNum + 1);
			dto.setSaveFileName(saveFileName);
			
			dao.insertData("imageTest.insertData", dto);
			
		}
		
		return SUCCESS;
		
	}
	
	public String list() throws Exception {
		
		CommonDAO dao = CommonDAOImpl.getInstance();
		
		MyUtil myUtil = new MyUtil();
		
		HttpServletRequest request = ServletActionContext.getRequest();
		
		String cp = request.getContextPath();
		
		int numPerPage = 9;
		int totalPage = 0;
		int totalDataCount = 0;
		
		int currentPage = 1;
		
		String pageNum = dto.getPageNum();
		
		if(dto.getPageNum()!=null&&!dto.getPageNum().equals("")) {
			currentPage = Integer.parseInt(pageNum);
		}
		
		totalDataCount = dao.getIntValue("imageTest.dataCount",dto.getNum());
		
		if(totalDataCount!=0) {
			totalPage = myUtil.getPageCount(numPerPage, totalDataCount);
		}
		
		if(currentPage>totalPage) {
			currentPage = totalPage;
		}
		
		int start = (currentPage-1)*numPerPage+1;
		int end = currentPage*numPerPage;
		
		Map<String, Object> hMap = new HashMap<String, Object>();
		hMap.put("start", start);
		hMap.put("end", end);
		
		List<Object> lists = dao.getListData("imageTest.listData", hMap);
		
		int listNum,n=0;
		
		//�ϷĹ�ȣ �����
		ListIterator<Object> it = lists.listIterator();
		
		while(it.hasNext()) {
			
			ImageTestDTO vo = (ImageTestDTO)it.next();
			
			listNum = totalDataCount - (start + n - 1);
			
			//vo.setListNum(totalDataCount - (start + n - 1));
			vo.setListNum(listNum);
			
			n++;
			
		}
		
		String urlList = cp + "/imageTest/list.action";
		String pageIndexList = myUtil.pageIndexList(currentPage, totalPage, urlList);
		
		//���Ϻ��� - ���� ������, null��
		/*HttpSession session = request.getSession();
			
		String root = session.getServletContext().getRealPath("/");
		String savePath = root + "pds" + File.separator + "image";
			
		//originalFileName = new String(originalFileName.getBytes("euc-kr"),"8859_1");
			
		String fullFilePath = savePath + File.separator + dto.getSaveFileName();
			
		is = new FileInputStream(fullFilePath);*/
		
		
		String imagePath = cp + "/pds/image";
		//�������
		String deletePath = cp + "/imageTest/delete.action";
		
		request.setAttribute("lists", lists);
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("totalPage",totalPage);
		request.setAttribute("totalDataCount", totalDataCount);
		request.setAttribute("pageIndexList", pageIndexList);
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("imagePath", imagePath);
		request.setAttribute("deletePath", deletePath);
		
		return SUCCESS;
		
	}
	
	//���� ����
	public String down() throws Exception {
			
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
			
		String root = session.getServletContext().getRealPath("/");
		String savePath = root + "pds" + File.separator + "image";
			
		originalFileName = new String(originalFileName.getBytes("euc-kr"),"8859_1");
			
		String fullFilePath = savePath + File.separator + saveFileName;
			
		is = new FileInputStream(fullFilePath);
		
		return SUCCESS;
			
	}
	
	public String delete() throws Exception {
		
		CommonDAO dao = CommonDAOImpl.getInstance();
		
		//ImageTestDTO dto = (ImageTestDTO)dao.getReadData("imageTest.readData", dto.getNum());
		
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		String root = session.getServletContext().getRealPath("/");
		String savePath = root + "pds" + File.separator + "saveFile";
		
		FileManager.doFileDelete(dto.getSaveFileName(), savePath);
		
		dao.deleteData("imageTest.deleteData", dto.getNum());
		
		return SUCCESS;
		
	}
	
	
	
	private InputStream is;
	private String saveFileName;
	private String originalFileName;
	
	public InputStream getIs() {
		return is;
	}

	public void setIs(InputStream is) {
		this.is = is;
	}

	public String getSaveFileName() {
		return saveFileName;
	}

	public void setSaveFileName(String saveFileName) {
		this.saveFileName = saveFileName;
	}

	public String getOriginalFileName() {
		return originalFileName;
	}

	public void setOriginalFileName(String originalFileName) {
		this.originalFileName = originalFileName;
	}
	
}
