package com.exe.springmybatis;

import java.util.List;

import org.springframework.context.support.GenericXmlApplicationContext;

public class CustomMain {

	public static void main(String[] args) {
		
		GenericXmlApplicationContext context = new GenericXmlApplicationContext("app-context.xml");
		
		CustomDAO dao = (CustomDAO)context.getBean("customDAO");
		
		CustomDTO dto;
		
		
		//insert
		/*
		dto = new CustomDTO();
		
		dto.setId(333);
		dto.setName("���μ�");
		dto.setAge(24);
		
		dao.insertData(dto);
		
		System.out.println("insert �Ϸ�!!");
		*/
		
		
		//select
		/*
		List<CustomDTO> lists = dao.getLists();
		for(CustomDTO dto1 : lists) {
			System.out.printf("%d %s %d\n",dto1.getId(),dto1.getName(),dto1.getAge());
		}
		
		System.out.println("select �Ϸ�!!");
		*/
		
		
		//One select
		/*
		dto = dao.getReadData(111);
		
		if(dto!=null) {
			System.out.printf("%d %s %d\n",dto.getId(),dto.getName(),dto.getAge());
		}
		
		System.out.println("select �Ϸ�!!");
		*/
		
		
		//update
		/*
		dto = new CustomDTO();
		dto.setId(111);
		dto.setName("���μ�");
		dto.setAge(25);
		
		dao.updateData(dto);
		
		System.out.println("update �Ϸ�!!");
		*/
		
		
		//delete
		/*
		dao.deleteData(111);
		
		System.out.println("delete �Ϸ�!!");
		*/
		
	}

}
