
function createXMLHttpRequest(){	
	
	var xmlReq = false;
	
	if(window.XMLHttpRequest){ //non-ms 브러우져
		
		xmlReq = new XMLHttpRequest();
	
	}else if(window.ActiveXObject){//ms 브러우져
		
		try{
			//IIS 5.0이후 버전
			xmlReq = new ActiveXObject("Msxml2.XMLHTTP");
		}catch(e1){	//IIS 5.0이전 버전	
			xmlReq = new ActiveXObject("Microsoft.XMLHTTP");				
		}
	}
	
	return xmlReq;
	
}