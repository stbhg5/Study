package com.exe.springdi1;

public class Message {
	
	public void sayHello(String name) {
		System.out.println(name + "�氡�氡...");
	}
	
}
