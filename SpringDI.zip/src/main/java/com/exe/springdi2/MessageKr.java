package com.exe.springdi2;

public class MessageKr implements Message {

	public void sayHello(String name) {
		
		System.out.println(name + "�� �氡�氡...");
		
	}

}
