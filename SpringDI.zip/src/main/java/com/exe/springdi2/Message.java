package com.exe.springdi2;

public interface Message {
	
	public void sayHello(String name);
	
}
