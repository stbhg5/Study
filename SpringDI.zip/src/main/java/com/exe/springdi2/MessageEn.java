package com.exe.springdi2;

public class MessageEn implements Message {

	public void sayHello(String name) {
		
		System.out.println("Hello," + name);
		
	}

}
