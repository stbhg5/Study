package com.exe.springdi4;

import org.springframework.stereotype.Component;

//�޽��� ��ġ��Ű�� @Qualifier("messageService")
@Component("messageService")
public class MyMessageService implements MessageService {

	public String getMessage() {
		return "�ȳ� �氡�氡..";
	}
	
}
