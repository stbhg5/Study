package com.exe.springdi4;

import org.springframework.context.support.GenericXmlApplicationContext;

public class MessageMain {

	public static void main(String[] args) {
		
		//ServiceConsumer sc = new ServiceConsumer();
		//sc.consumerService();
		
		GenericXmlApplicationContext context = new GenericXmlApplicationContext("app-context.xml");
		
		ServiceConsumer sc = (ServiceConsumer)context.getBean("serviceConsumer");//app-context.xml �ҷ���
		sc.consumerService();
		
	}
	
}
