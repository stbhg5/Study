package com.exe.springdi4;

public interface MessageService {
	
	public String getMessage();
	
}
