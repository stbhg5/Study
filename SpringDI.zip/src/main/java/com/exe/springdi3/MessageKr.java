package com.exe.springdi3;

public class MessageKr implements Message {

	public void sayHello(String name) {
		
		System.out.println(name + "�� �氡�氡...");
		
	}

}
