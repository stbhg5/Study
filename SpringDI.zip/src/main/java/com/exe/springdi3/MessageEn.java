package com.exe.springdi3;

public class MessageEn implements Message {

	public void sayHello(String name) {
		
		System.out.println("Hello," + name);
		
	}

}
