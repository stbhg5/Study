package com.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller("demo.mainController")
public class MainController {
	
	@RequestMapping(value="/main.action",method={RequestMethod.GET,RequestMethod.POST})
	public String method() {//com.anno�� MainController ma.action���� ��ġ��
		
		return "mainLayout"; //tiles.xml
		
	}

}
