package com.chain;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.Preparable;

//ü�� : ȸ������ �� �ٷ� �α���â ������ �ϴ� ���ӵ��� ����

public class LoginAction extends ActionSupport implements Preparable,ModelDriven<UserDTO>{
	
	private UserDTO dto;
	private String message;
	
	public UserDTO getDto() {
		return dto;
	}
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public UserDTO getModel() {
		return dto;
	}
	@Override
	public void prepare() throws Exception {
		dto = new UserDTO();
	}
	
	public String login() throws Exception {//http://localhost:8080/struts2/chain/login.action

		if(dto==null||dto.getMode()==null||dto.getMode().equals("")) {
			return INPUT;
		}

		message = dto.getUserId() + "�� �α��� ����!!";

		return SUCCESS;

	}
	
}
