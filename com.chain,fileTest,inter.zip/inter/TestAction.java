package com.inter;

import com.opensymphony.xwork2.ActionSupport;

public class TestAction extends ActionSupport {
	
	private String userName;
	private String userPwd;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPwd() {
		return userPwd;
	}
	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}
	
	@Override
	public String execute() throws Exception {//http://localhost:8080/struts2/interTest/write.action

		//�۾��ڵ�
	
		return SUCCESS;

	}
	
}
