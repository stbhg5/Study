
function createXMLHttpRequest() {
	
	//XMLHttpRequest 객체 생성
	var xmlReq = false;
	
	if(window.XMLHttpRequest) {//non-ms 브라우져(크롬,사파리)의 경우 객체생성, ms 브라우져 11이후 - 주로 많이 쓴다.
		xmlReq = new XMLHttpRequest();
	}else if(window.ActiveXObject) {//ms 브라우져인 경우
		
		try{
			//IIS5.0이후 버전
			xmlReq = new ActiveXObject("Msxml2.XMLHTTP");
		}catch(e1) {//IIS5.0이전 버전
			xmlReq = new ActiveXObject("Microsoft.XMLHTTP");
		}
		
	}
	
	return xmlReq;
	
}