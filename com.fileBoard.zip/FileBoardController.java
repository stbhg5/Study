package com.fileBoard;

import java.io.File;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import com.util.FileManager;
import com.util.MyUtil;
import com.util.dao.CommonDAO;

@Controller("fileBoard.fileBoardController")
public class FileBoardController {
	
	@Resource(name="dao")
	private CommonDAO dao;
	
	@Resource(name="myUtil")
	private MyUtil myUtil;
	
	@Resource(name="fileManager")
	private FileManager fileManager;
	
	//http://localhost:8080/spring2/file/created.action
	@RequestMapping(value="/file/created.action",method= {RequestMethod.GET,RequestMethod.POST})
	public String created(FileBoardCommand command,HttpServletRequest request,HttpSession session) throws Exception {
		
		if(command.getUpload()==null||command.getMode()==null||command.getMode().equals("")) {
			
			request.setAttribute("mode", "insert");
			
			return "fileBoard/created";
			
		}
		
		MultipartFile file = command.getUpload();
		InputStream is = file.getInputStream();
		
		String root = session.getServletContext().getRealPath("/");
		String path = root + "pds" + File.separator + "data";
		String originalFileName = command.getUpload().getOriginalFilename();
		String newFileName = FileManager.doFileUpload(is, originalFileName, path);
		
		int maxNum = dao.getIntValue("fileBoard.maxNum");
		command.setNum(maxNum + 1);
		command.setOriginalFileName(originalFileName);
		command.setSaveFileName(newFileName);
		
		dao.insertData("fileBoard.insertData", command);
		
		return "redirect:/file/list.action";
		
	}
	
	@RequestMapping(value="/file/list.action",method= {RequestMethod.GET,RequestMethod.POST})
	public String list(HttpServletRequest request,HttpSession session) throws Exception {
		
		int numPerPage = 5;
		int totalPage = 0;
		int totalDataCount = 0;
		
		String cp = request.getContextPath();
		String pageNum = request.getParameter("pageNum");
		
		int currentPage = 1;
		
		if(pageNum!=null && !(pageNum.equals(""))) {
			currentPage = Integer.parseInt(pageNum);
		}
		
		totalDataCount = dao.getIntValue("fileBoard.dataCount");
		
		if(totalDataCount!=0) {
			totalPage = myUtil.getPageCount(numPerPage,totalDataCount);
		}
		
		if(currentPage>totalPage) {
			currentPage = totalPage;
		}
		
		Map<String, Object> hMap = new HashMap<String, Object>();
		
		int start = (currentPage-1)*numPerPage+1;
		int end = currentPage*numPerPage;
		
		hMap.put("start", start);
		hMap.put("end", end);
		
		List<Object> lists = (List<Object>)dao.getListData("fileBoard.listData", hMap);
		
		//��ȣ ������ �۾�
		Iterator<Object> it = lists.iterator();
		
		int listNum, n = 0;
		String str;
		
		while(it.hasNext()) {
			
			FileBoardCommand dto = (FileBoardCommand)it.next();
			listNum = totalDataCount - (start + n - 1);
			dto.setListNum(listNum);
			n++;
			
			//���� �ٿ�ε� ���
			str = cp + "/file/download.action?num=" + dto.getNum();
			dto.setUrlFile(str);
			
		}
		
		String urlList = cp + "/file/list.action";
		
		request.setAttribute("lists", lists);
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("totalPage", totalPage);
		request.setAttribute("totalDataCount", totalDataCount);
		request.setAttribute("pageIndexList", myUtil.pageIndexList(currentPage, totalPage, urlList));
		
		return "fileBoard/list";
		
	}
	
	@RequestMapping(value="/file/deleted.action",method= {RequestMethod.GET,RequestMethod.POST})
	public String deleted(FileBoardCommand command,HttpServletRequest request,HttpSession session) throws Exception {
		
		String root = session.getServletContext().getRealPath("/");
		String path = root + "pds" + File.separator + "data";
		int num = Integer.parseInt(request.getParameter("num"));
		
		//�����ؾ� �ϴ� �����Ͱ� �о����
		FileBoardCommand dto = (FileBoardCommand)dao.getReadData("fileBoard.readData",num);
		String saveFileName = dto.getSaveFileName();
		FileManager.doFileDelete(saveFileName, path);
		
		//DB����
		dao.deleteData("fileBoard.deleteData", num);
		
		return "redirect:/file/list.action";
		
	}
	
	@RequestMapping(value="/file/download.action",method= {RequestMethod.GET,RequestMethod.POST})
	public String download(HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception {
		
		String root = session.getServletContext().getRealPath("/");
		String path = root + "pds" + File.separator + "data";
		int num = Integer.parseInt(request.getParameter("num"));
		
		//�ٿ�ε� ���� �����Ͱ� �о����
		FileBoardCommand dto = (FileBoardCommand)dao.getReadData("fileBoard.readData",num);
		
		if(dto==null) {
			return "redirect:/file/list.action";
		}
		
		//�ٿ�ε� ����
		boolean flag = FileManager.doFileDownload(response, dto.getSaveFileName(), dto.getOriginalFileName(), path);
		if(!flag) {
			
			//�ٿ�ε� ���� ������ �� ����
			response.setContentType("text/html;charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.print("<script type='text/javascript'>");
			out.print("alert('�ٿ�ε� ����!!');");
			out.print("history.back();");
			out.print("</script>");
			
		}
		
		return null;
		
	}
	
}
