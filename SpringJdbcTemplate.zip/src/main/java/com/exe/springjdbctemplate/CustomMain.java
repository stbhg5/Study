package com.exe.springjdbctemplate;

import org.springframework.context.support.GenericXmlApplicationContext;

public class CustomMain {

	public static void main(String[] args) {
		
		GenericXmlApplicationContext context = new GenericXmlApplicationContext("app-context.xml");
		
		CustomDAO dao = (CustomDAO)context.getBean("customDAO");
		
		CustomDTO dto;
		
		//insert
		dto = new CustomDTO();
		
		dto.setId(222);
		dto.setName("���γ�");
		dto.setAge(25);
		
		dao.insertData(dto);
		
		System.out.println("insert �Ϸ�!!");
		
	}

}
