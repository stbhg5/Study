package com.exe.springjdbctemplate;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.sql.DataSource;

public class CustomDAO {
	
	//�޼ҵ� ������ ���� - ���� JDBC�����̱⿡ ������̼� �ȵ�.
	private DataSource dataSource;
	
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	//5���� �޼ҵ� (insert,update,delete,��üselect,�ϳ�select)
	Connection conn = null;
	
	public int insertData(CustomDTO dto) {
		
		int result = 0;
		
		PreparedStatement pstmt = null;
		String sql;
		
		try {
			
			conn = dataSource.getConnection();
			
			sql = "insert into custom (id,name,age) values (?,?,?)";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, dto.getId());
			pstmt.setString(2, dto.getName());
			pstmt.setInt(3, dto.getAge());
			
			result = pstmt.executeUpdate();
			
			pstmt.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return result;
		
	}
	
}
