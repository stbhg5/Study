/*
Object Mapper : 자바스크립트 객체와 데이터베이스 객체를 서로 매칭해서 바꿀수있게
하는것을 오브젝트 맵퍼라고하고 가장 많이 사용하는 모듈이 몽구스모듈. 
 
몽구스(mongoose) : 데이터베이스를 테이블이나 엑셀 시트처럼
데이터베이스를 쉽게 다룰수있는 모듈

Schema (String,Number,Boolean,Array,Buffer,Date,ObjectId,Mixed) 
어떤 문서에는 name이 있고 다른 문서에는 name이 없을 수도 있기때문에 
일정한 조건으로 적용하기가 어려움
관계형 데이터베이스처럼 조회 조건을 공통적으로 적용하기위해 만들고
그 스키마에 정해진 규칙으로 문서(열) 객체를 저장 할수있다
특히 일정한 틀에 맞는 자바스크립트 객체를 그대로 DB에 저장하거나 Schema에 의해
저장된 문서 객체를 자바스크립트 객체로 변환시킬수 있음
* 스키마를 사용하기 위해서는 model을 정의 함


[스키마객체 정의]
*스키마 타입
String,Number,Boolean,Array,Buffer,Date,ObjectId,Mixed

unique:true : 고유값(pk)
required:true : 필수입력(not null)
index:hashed : 인덱스 생성
expires:'1d' : 유효시간

UserSchema = mongoose.Schema({	//자바스크립트객체를전달
  id: {type:String,required:true,unique:true},
  password: {type:String,required:true},
  name: {type:String,index:'hashed'}, 
  age: Number,
  created: {type:Date,index:{unique:false,expires:'1d'}}	
});

*몽구스 메소드 
connect, Schema(), model

*모델객체 정의
UserModel = mongoose.model("users", UserSchema);

*model객체의 메소드
find, save, update, remove

*id:suzi로 찾은 데이터를 nam:김수지 로 수정
UserModel.where({id:'suzi'}).update({name:'김수지'},function(err,result){})

*/

var express = require("express");
var http = require("http");
var path = require("path");

var serveStatic = require("serve-static")
var expressErrorHandler = require("express-error-handler");
var cookieParser = require("cookie-parser");
var expressSession = require("express-session");

//mongoose 모듈
var mongoose = require("mongoose");

//익스프레스 객체 생성
var app = express();
app.set("port",process.env.PORT || 3000);

//미들웨어 추가
app.use(express.urlencoded({extended: true}));
app.use(express.json());

app.use("/public",serveStatic(path.join(__dirname,"public")));

//몽고디비 모듈
//var MongoClient = require("mongodb").MongoClient;

//데이터베이스 객체를 위한 변수
var database;

//데이터베이스 스키마 객체를 위한 변수
var UserSchema;

//데이터베이스 모델 객체를 위한 변수
var UserModel;


function connectDB(){
	
	//데이터베이스 연결 정보
	var databaseUrl = "mongodb://localhost:27017/shopping";
		
	//데이터베이스 연결
	/*
	MongoClient.connect(databaseUrl,function(err, dbase){
		
		if(err) throw err;
		
		console.log("데이터베이스에 연결되었습니다. : " + databaseUrl);
		
		database = dbase.db("shopping");
		
	});
	*/
	
	//몽구스로 데이터베이스 연결
	mongoose.connect(databaseUrl);
	database = mongoose.connection;
	
	database.on("open",function(){
		
		console.log("데이터베이스에 연결되었습니다. : " + databaseUrl);
				
		UserSchema = mongoose.Schema({
		  id: {type: String, required: true, unique: true},		    
		  name: {type: String, index: "hashed"},
		  password: {type: String, required: true},
		  age: {type: Number, "default": 20},
		  created: {type: Date, index: {unique: false}, "default": Date.now}
		});
		
		//스키마 객체에 메소드 추가(static(), method() : 2가지 방법)
		
		// 스키마에 static으로 findById 메소드 추가(로그인에서 사용)	
		UserSchema.static('findById', function(id, callback) { 
			return this.find({id:id}, callback);
		});
		
		// 스키마에 static으로 findAll 메소드 추가(전체데이터 가져오기)	
		UserSchema.static("findAll", function(callback){
			return this.find({}, callback);
		});			
		console.log("UserSchema 정의함");
		
		
		//Schema를 collection에 model로 적용
		UserModel = mongoose.model("users2",UserSchema);
		console.log("UserModel 정의함");	
		
	});
	
	database.on("error",console.error.bind(console,"몽구스 연결 에러..."));
	
	database.on("disconnected",function(){
		
		console.log("데이터베이스 연결이 끊겼습니다");
		setInterval(connectDB,5000);
		
	});
	
}

//사용자 인증 함수
var authUser = function(database,id,password,callback){
	
	console.log("authUser 호출..");
	
	//users Collection(table) 참조
	//var users = database.collection("users");
	
	//id,pw를 이용해서 검색
	UserModel.findById(id,function(err,result){
		
		if(err){
			callback(err,null);//에러
			return;
		}
		
		if(result.length>0){			
			
			if(result[0]._doc.password==password){
						
				callback(null,result);//비밀번호 일치
			
			}else{
				callback(null,null);//사용자 못찾음
			}
			
		}else{			
			callback(null,null);
		}	
		
	});
	
};

//사용자 추가하는 함수
var addUser = function(database,id,pwd,name,callback){
	
	console.log("addUser 호출");
	
	//var users = database.collection("users");
	
	var user = new UserModel({"id":id, "password":pwd, "name":name});
		
	user.save(function(err,result){
		
		if(err){
			callback(err,null);
			return;
		}		
		
		console.log("사용자 추가");		
		
		callback(null,result);		
		
	});
	
};


//라우터 객체 
var router = express.Router();

//사용자 로그인 라우터
router.route("/process/login").post(function(req,res){
	
	console.log("login 호출");
	
	var id = req.body.id;
	var pwd = req.body.pwd;
	
	//사용자 인증
	if(database){
		
		authUser(database, id, pwd, function(err,result){
			
			if(err) throw err;
			
			if(result){
				
				var userName = result[0].name;
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h1>로그인 성공</h1>");
				res.write("<div>아이디: " + id + "</div>");
				res.write("<div>이름: " + userName + "</div>");
				
				res.write("<br/><br/><a href='/public/login.html'>로그인</a>");
				res.write("<br/><br/><a href='/public/listUser.html'>리스트</a>");
				res.end();
				
			}else{
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h1>로그인 실패</h1>");
				res.write("<div>아이디와 패스워드를 다시 확인하세요.</div>");
				
				res.write("<br/><br/><a href='/public/login.html'>로그인</a>");
				res.end();
				
			}
			
		});
		
	}else{
		
		res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
		res.write("<h1>데이터베이스 연결 실패</h1>");
		res.write("<div>데이터베이스에 연결하지 못했습니다.</div>");
		res.end();
		
	}
	
});

//사용자 추가 라우터
router.route("/process/addUser").post(function(req,res){
	
	console.log("addUser 호출");
	
	var id = req.body.id;
	var pwd = req.body.pwd;
	var name = req.body.name;
	
	if(database){
		
		addUser(database, id, pwd, name, function(err,result){
			
			if(err) throw err;
			
			if(result){
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h1>사용자 추가 성공</h1>");
				res.write("<br/><br/><a href='/public/login.html'>로그인</a>");
				res.end();				
				
			}else{
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h1>사용자 추가 실패</h1>");
				res.write("<br/><br/><a href='/public/login.html'>로그인</a>");
				res.end();
				
			}
			
		});
		
	}else{
		
		res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
		res.write("<h1>데이터베이스 연결 실패</h1>");
		res.write("<div>데이터베이스에 연결하지 못했습니다.</div>");
		res.end();
		
	}
	
});

//사용자 리스트 함수
router.route("/process/listUser").post(function(req,res){
	
	if(database){
		
		//모든 사용자 검색
		UserModel.findAll(function(err,result){
			
			if(err){
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h2>사용자 리스트 조회중 에러 발생</h2>");
				res.end();				
				
				return;
			}
			
			
			if(result){
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h2>사용자 리스트</h2>");
				res.write("<div><ul>");
				
				for(var i=0;i<result.length;i++){
					
					var id = result[i]._doc.id;
					var name = result[i]._doc.name;
					var age = result[i]._doc.age;
					
					res.write("<li>#" + (i+1) + " : " 
							+id + ", " + name + ", " + age + "</li>");
					
				}
				
				res.write("</ul></div>");
				res.write("<br/><br/><a href='/public/listUser.html'>리스트</a>");
				res.end();				
				
			}else{
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<h2>사용자 리스트 조회 실패</h2>");
				res.end();
			}
			
		});
		
	}else{
		
		res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
		res.write("<h1>데이터베이스 연결 실패</h1>");
		res.write("<div>데이터베이스에 연결하지 못했습니다.</div>");
		res.end();	
		
	}
	
});


//라우터 등록
app.use("/",router);

//404에러 페이지
var errorHandler = expressErrorHandler({
	
	static:{
		'404' : "./public/404.html"
	}
	
});

app.use(expressErrorHandler.httpError(404));
app.use(errorHandler);

//Express서버 시작
http.createServer(app).listen(app.get("port"),function(){
	
	console.log("Express 서버를 시작했습니다 : " + app.get("port"));
	
	connectDB();
	
});



