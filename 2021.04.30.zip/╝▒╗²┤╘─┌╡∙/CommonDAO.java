package com.util.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface CommonDAO {
	
	//�߰�
	public void insertData(String id, Object value) throws SQLException;
	
	//����
	public int updateData(String id, Object value) throws SQLException;
	public int updateData(String id, Map<String, Object> map) throws SQLException;
	
	//����
	public int deleteAllData(String id) throws SQLException;
	public int deleteData(String id, Map<String, Object> map) throws SQLException;
	public int deleteData(String id, Object value) throws SQLException;
	
	//select
	public Object getReadData(String id) throws SQLException;
	public Object getReadData(String id, Map<String, Object> map) throws SQLException;
	public Object getReadData(String id, Object value) throws SQLException;
	
	//1�� select
	public int getIntValue(String id) throws SQLException;
	public int getIntValue(String id, Map<String, Object> map) throws SQLException;
	public int getIntValue(String id, Object value) throws SQLException;
	
	//all select
	public List<Object> getListData(String id);
	public List<Object> getListData(String id, Object value);
	public List<Object> getListData(String id, Map<String, Object> map);	

}




