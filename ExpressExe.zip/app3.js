
//http://localhost:3000/login.html

//이미 만들어져 있는 미들웨어(static,body-parser)
//static : 특정 폴더의 파일을 path모듈로 접근 가능하게 함 - 폴더형식의 접근가능하게 함
//ExpressExe/public/index.html -> http:localhost:3000/index.html
//ExpressExe/public/images/suzi.png -> http:localhost:3000/images/suzi.png

//전통 웹에 따르면 Web Contents 같은 기본 Deafault폴더인 public 폴더 만들기

//GET방식은 Default
//body-parser : POST방식 요청지원

//익스프레스 모듈
var express = require("express");
var http = require("http");
var path = require("path");

//Express 미들웨어
var bodyParser = require("body-parser"); //POST방식 시 반드시 필요
var serveStatic = require("serve-static"); //특정 폴더로 접근 가능하게 함

//익스프레스 객체 생성
var app = express(); //app가 익스프레스 서버다.

//기본 포트를 app객체에 속성으로 설정
//express 객체의 메소드 (set,get,use)
app.set("port",process.env.PORT || 3000); //환경설정에 포트번호 있으면 쓰고 없으면 3000써라.

//미들웨어 추가
app.use(bodyParser.urlencoded({extended: false})); //false : <form enctype="application/x-www-form-urlencoded"> 쓰겠다.

app.use(bodyParser.json()); //JSON형태 데이터 읽을 수 있게 하겠다. : JSON데이터 파싱

app.use(serveStatic(path.join(__dirname,'public'))); //주소합치기, 폴더명과 폴더명 앞의 주소명 합쳐서 하나로 처리

app.use(function(req,res,next) {//next가 chain처럼 다음으로 넘겨줌
	
	console.log("첫번째 미들웨어에서 요청을 처리함.");
	
	var paramId = req.query.id || req.body.id; //GET / POST
	var paramPwd = req.query.pwd || req.body.pwd;
	
	res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
	res.write("<h1>Express 서버에서 응답한 결과입니다.</h1>");
	
	res.write("<div>Param id: " + paramId + "</div>");
	res.write("<div>Param pwd: " + paramPwd + "</div>");
	res.end();
	
});

//Express서버 시작
http.createServer(app).listen(app.get("port"),function() {
	console.log("Express 서버를 시작했습니다 : " + app.get("port"));
});
