
//http://localhost:3000/process/showCookie
//http://localhost:3000/process/setUserCookie
//쿠키
//쿠키보기 : 홈페이지 - F12키 - Application - Cookies에서 쿠키 보기

//익스프레스 모듈
var express = require("express");
var http = require("http");
var path = require("path");

//Express 미들웨어
var bodyParser = require("body-parser"); //POST방식 시 반드시 필요
var serveStatic = require("serve-static"); //특정 폴더로 접근 가능하게 함

//Error 핸들러 모듈
var expressErrorHandler = require("express-error-handler");

//Cookie 모듈
var cookieParser = require("cookie-parser");

//익스프레스 객체 생성
var app = express(); //app가 익스프레스 서버다.

//기본 포트를 app객체에 속성으로 설정
//express 객체의 메소드 (set,get,use)
app.set("port",process.env.PORT || 3000); //환경설정에 포트번호 있으면 쓰고 없으면 3000써라.

//미들웨어 추가
app.use(bodyParser.urlencoded({extended: false})); //false : <form enctype="application/x-www-form-urlencoded"> 쓰겠다.

app.use(bodyParser.json()); //JSON형태 데이터 읽을 수 있게 하겠다. : JSON데이터 파싱

//사용할 주소 /public
app.use("/public",serveStatic(path.join(__dirname,'public'))); //주소합치기, 폴더명과 폴더명 앞의 주소명 합쳐서 하나로 처리

//쿠키객체 app등록
app.use(cookieParser());

//라우터 객체 - 만든 이유는 이러한 주소형태 쓰기 위해서
var router = express.Router();


router.route("/process/showCookie").get(function(req,res) {//GET방식으로 입력하고 들어가겠다고 해서 get방식
	
	console.log("showCookie 호출됨");
	
	res.send(req.cookies); //쿠키 보기
	
});

router.route("/process/setUserCookie").get(function(req,res) {
	
	console.log("setUserCookie 호출됨");
	
	//쿠키 만들기
	res.cookie("user",{
		
		id:"suzi",
		name:"배수지",
		authorized:true //인증작업 - 지금은 의미X
		
	});
	
	//redirect로 응답
	res.redirect("/process/showCookie");
	
});

//미들웨어가 하는 것을 라우터가 하지만 미들웨어 없어선 안된다.
//라우터 객체를 app에 등록
app.use("/",router);

//404에러 페이지
var errorHandler = expressErrorHandler({
	
	static:{//404에러나면 html 찾아가라
		'404' : "./public/404.html"
	}
	
});

app.use(expressErrorHandler.httpError(404));
app.use(errorHandler);

//Express서버 시작
http.createServer(app).listen(app.get("port"),function() {
	console.log("Express 서버를 시작했습니다 : " + app.get("port"));
});
