
//http://localhost:3000/
//익스프레스 서버와 미들웨어

//익스프레스 모듈
var express = require("express");
var http = require("http");

//익스프레스 객체 생성
var app = express(); //app가 익스프레스 서버다.

/*
익스프레스에 미들웨어 만들기
미들웨어 : 하나의 독립된 함수(메소드) - use 메소드로 설정
클라이언트의 요청 -> 미들웨어 #1 -> 라우터(요청패턴 /가 왔을 때) -> 클라이언트에게 응답
클라이언트의 요청 -> 미들웨어 #2 -> 라우터(요청패턴 /users가 왔을 때) -> 클라이언트에게 응답
클라이언트의 요청 -> 미들웨어 #3 -> 라우터(요청패턴 /sales가 왔을 때) -> 클라이언트에게 응답
*/

app.use(function(req,res,next) {//next가 chain처럼 다음으로 넘겨줌
	
	console.log("첫번째 미들웨어에서 요청을 처리함.");
	/*
	res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
	res.end("<h1>Express 서버에서 응답한 결과입니다.</h1>");
	*/
	req.user = "suzi"; //req에 담기
	
	next(); //넘기기
	
});

app.use("/",function(req,res,next) {//구분을 "/"로 함 (구분하기 위함)
	
	console.log("두번째 미들웨어에서 요청을 처리함.");
	
	res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
	res.end("<h1>Express 서버에서 " + req.user +"가 응답한 결과입니다.</h1>");
	
});


//기본 포트를 app객체에 속성으로 설정
//express 객체의 메소드 (set,get,use)
app.set("port",process.env.PORT || 3000); //환경설정에 포트번호 있으면 쓰고 없으면 3000써라.

//Express서버 시작
http.createServer(app).listen(app.get("port"),function() {
	console.log("Express 서버를 시작했습니다 : " + app.get("port")); //3000
});
