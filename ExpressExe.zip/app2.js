
//http://localhost:3000/?name=suzi
//미들웨어 데이터 넘기는 방식

//익스프레스 모듈
var express = require("express");
var http = require("http");

//익스프레스 객체 생성
var app = express(); //app가 익스프레스 서버다.

app.use(function(req,res,next) {//next가 chain처럼 다음으로 넘겨줌
	
	console.log("첫번째 미들웨어에서 요청을 처리함.");
	
	//res.send({name:"정인선",age:27});
	//res.status(403).send("접근금지"); //403 에러
	//res.sendStatus(403); //Forbidden 뜬다
	//res.redirect("http://m.naver.com"); //리다이렉트
	
	//GET방식 / POST방식
	//GET : req.query.name
	//POST : req.body.name
	//GET/POST : req.param("name")
	
	//http://localhost:3000/?name=suzi - /?들어가면 Node.js로 만든 것이다.
	
	var userAgent = req.header("User-Agent"); //브라우저 정보 보여줌
	var paramName = req.query.name; //GET방식으로 넘어옴
	
	res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
	res.write("<h1>Express 서버에서 응답한 결과입니다.</h1>");
	
	res.write("<div>User-Agent: " + userAgent + "</div>");
	res.write("<div>Param name: " + paramName + "</div>");
	
});

//기본 포트를 app객체에 속성으로 설정
//express 객체의 메소드 (set,get,use)
app.set("port",process.env.PORT || 3000); //환경설정에 포트번호 있으면 쓰고 없으면 3000써라.

//Express서버 시작
http.createServer(app).listen(app.get("port"),function() {
	console.log("Express 서버를 시작했습니다 : " + app.get("port"));
});
