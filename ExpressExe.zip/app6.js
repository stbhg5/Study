
//http://localhost:3000/public/login3.html
//세션

//익스프레스 모듈
var express = require("express");
var http = require("http");
var path = require("path");

//Express 미들웨어
var bodyParser = require("body-parser"); //POST방식 시 반드시 필요
var serveStatic = require("serve-static"); //특정 폴더로 접근 가능하게 함

//Error 핸들러 모듈
var expressErrorHandler = require("express-error-handler");

//Cookie 모듈
var cookieParser = require("cookie-parser");

//Session모듈
var expressSession = require("express-session");

//익스프레스 객체 생성
var app = express(); //app가 익스프레스 서버다.

//기본 포트를 app객체에 속성으로 설정
//express 객체의 메소드 (set,get,use)
app.set("port",process.env.PORT || 3000); //환경설정에 포트번호 있으면 쓰고 없으면 3000써라.

//미들웨어 추가
app.use(bodyParser.urlencoded({extended: false})); //false : <form enctype="application/x-www-form-urlencoded"> 쓰겠다.

app.use(bodyParser.json()); //JSON형태 데이터 읽을 수 있게 하겠다. : JSON데이터 파싱

//사용할 주소 /public
app.use("/public",serveStatic(path.join(__dirname,'public'))); //주소합치기, 폴더명과 폴더명 앞의 주소명 합쳐서 하나로 처리

//쿠키객체 app등록
app.use(cookieParser());

//세션설정
//secret : 세션을 임의로 변조하는 것을 방지하기 위한 값. 이 값을 통해 세션을 암호화해서 저장
//resave : 세션을 언제든지 저장할지 정하는 값
//saveUninitialized : 세션이 저장 되기 전에 Uninitialized 상태로 만듦. - 세션 저장공간 초기화 안함
app.use(expressSession({
	secret: "my key", //아무거나 써도 됨 - 가져가서 암호화 시킴
	resave: true, //일반적으로 true
	saveUninitialized: true //일반적으로 true - 세션 공간 초기화
}));

//라우터 객체 - 만든 이유는 이러한 주소형태 쓰기 위해서 - 지우면 안됨
var router = express.Router();

//라우터가 미들웨어 흡수해서 사용, 메소드 역할
//router.route("/process/login").get(function(req,res) {//GET방식으로 입력하고 들어가겠다고 해서 get방식
//router.post("/process/login",function(req,res) {
app.post("/process/login",function(req,res) {//router도 express 안에 있으니 가능
	
	console.log("login 호출");
	
	var id = req.body.id;
	var pwd = req.body.pwd;
	
	if(req.session.user) {
		
		console.log("이미 로그인 되어 상품 페이지로 이동합니다.");
		
		res.redirect("/public/product.html"); //실제 물리적 주소 찾아감(포워드처럼)
		
	}else {
		
		if(id=="suzi" && pwd=="a123") {
			
			//세션 저장
			req.session.user = {
					id:id,
					name:"배수지",
					authorized:true //인증작업
			};
			
			//사용자에게 보여줄 표시
			res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"}); //200인증되면 실행해라
			res.write("<h1>로그인 성공</h1>");
			
			res.write("<div>id: " + id + "</div>");
			res.write("<div>pwd: " + pwd + "</div>");
			res.write("<div>name: " + req.session.user.name + "</div>");
			
			res.write("<br/><br/><a href='/process/product'>상품 페이지</a>");
			
			res.end();
			
		}
		
	}
	
});

app.get("/process/product",function(req,res) {//주소로 들어오니 get
	
	console.log("product 호출");
	
	if(req.session.user) {
		
		res.redirect("/public/product.html");
		
	}else {
		
		res.redirect("/public/login3.html");
		
	}
	
});

app.get("/process/logout",function(req,res) {
	
	console.log("logout 호출");
	
	if(req.session.user) {
		
		//req.session.destroy(); //단순 세션 삭제
		
		req.session.destroy(function (err) {
			
			if(err) throw err;
			
			res.redirect("/public/login3.html");
			
		});
		
	}else {
		
		res.redirect("/public/login3.html");
		
	}
	
});

//미들웨어가 하는 것을 라우터가 하지만 미들웨어 없어선 안된다.
//라우터 객체를 app에 등록
app.use("/",router);

//404에러 페이지
var errorHandler = expressErrorHandler({
	
	static:{//404에러나면 html 찾아가라
		'404' : "./public/404.html"
	}
	
});

app.use(expressErrorHandler.httpError(404));
app.use(errorHandler);

//Express서버 시작
http.createServer(app).listen(app.get("port"),function() {
	console.log("Express 서버를 시작했습니다 : " + app.get("port"));
});
