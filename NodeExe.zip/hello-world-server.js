var http = require('http');
http.createServer(function handler(req, res) {
	
    res.writeHead(200, {'Content-Type': 'text/plain;charset=utf-8'}); //클라이언트에게 보여주고 정상실행시 200
    res.end('안녕 Node첫시간\n');
    
}).listen(1337, 'localhost'); //1337포트와 이 아이피로 왔을 때 반응 보여라
console.log('Server running at http://localhost:1337/');
