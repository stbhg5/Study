
//http://localhost:3000/

//Web
var http = require("http");

//웹 서버 객체를 만듦
var server = http.createServer(function(req,res) {//여기에 넣어도 된다!!
	
	console.log("클라이언트의 요청이 들어왔습니다."); //request로 들어오고 response가 없으니 창이 없다.
	
	res.writeHead(200,{"Content-Type":"text/html;charset=UTF-8"});
	res.write("<!DOCTYPE html>");
	res.write("<html>");
	res.write("<head>");
	res.write("<title>응답페이지</title>");
	res.write("</head>");
	res.write("<body>");
	res.write("<h1>서버에서 응답 받기</h1>");
	res.write("</body></html>");
	res.end(); //끝이 있어야 호출이 된다!!
	
	//이부분을 Angular, React로 한다. 앞으로 길어진다.
	
});

var host = "localhost";
var port = 3000; //6535까지 있는데 1~2000은 시스템이 쓰니 그 이상부터 마음대로 적용

server.listen(port,host,50000,function(){//숫자 : 동시접속자 수
	console.log("웹서버가 시작 되었습니다." + port);
}); //반환값이 없으면 창 안뜸

//클라이언트 연결 이벤트 처리
//on메소드로 connection 전달하고 소켓을 받음
server.on("connection",function(socket){
	console.log("클라이언트가 접속을 했습니다." + socket.remoteAddress + " : " + socket.remotePort);
});

//클라이언트 요청 이벤트 처리
server.on("request",function(req,res) {//request, response 그릇
	/*
	console.log("클라이언트의 요청이 들어왔습니다."); //request로 들어오고 response가 없으니 창이 없다.
	
	res.writeHead(200,{"Content-Type":"text/html;charset=UTF-8"});
	res.write("<!DOCTYPE html>");
	res.write("<html>");
	res.write("<head>");
	res.write("<title>응답페이지</title>");
	res.write("</head>");
	res.write("<body>");
	res.write("<h1>서버에서 응답 받기</h1>");
	res.write("</body></html>");
	res.end(); //끝이 있어야 호출이 된다!!
	*/
});

//서버 종료 이벤트
server.on("close",function() {
	console.log("서버가 종료됩니다.");
});

//emit()은 js파일에서 호출할 때이다. 실제로 잘 안쓴다.
//지금은 브라우져 환경이라 emit() 안쓴다.

//비오면 네트워크 느려진다.
//스프링 부트도 자체 톰캣서버가 있다. 그래서 세팅 공부해놓아야 한다.
