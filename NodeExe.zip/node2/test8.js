
//폴더 만들기 / 지우기
var fs = require("fs");


fs.mkdir("./doc",function(err) {
	
	if(err) throw err;
	
	console.log("doc 폴더 생성...");
	
});


fs.rmdir("./doc",function(err) {
	
	if(err) throw err;
	
	console.log("doc 폴더 삭제...");
	
});


//한번에 실행하면 만들고 지우니 번갈아 주석처리하고 실행
