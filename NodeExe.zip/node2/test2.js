/*
이벤트
EventEmitter를 사용 : 이벤트를 주고 받음
process 객체는 내부적으로 EventEmitter를 상속 받았음
★on(event,function) : 이벤트가 전달될 객체에 이벤트 리스너 설정, 어디선가 호출하면 실행되는 이벤트
emit() : 이벤트를 다른쪽으로 전달하는 메소드
emit는 on을 호출한다. on이 여러개일 수 있다.
*/

//1. event 사용하기 - process
process.on("exit",function() {//exit는 이벤트 이름(사용자 정의)
	console.log("exit 이벤트가 발생함");
});

setTimeout(function() {
	
	console.log("4초 후에 시스템 종료 시도함..");
	
	process.exit(); //위 exit 호출 - 없어도 process엔 자체적인 emit가 있어서 코딩에 의해 실행됨.
	
},4000);

process.on("tick",function(count) {
	console.log("tick 이벤트 발생함: " + count);
});

setTimeout(function() {
	
	console.log("2초 후에 tick 이벤트 호출 시도함");
	
	process.emit("tick","5");
	
},2000);
