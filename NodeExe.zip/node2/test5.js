
//파일 만들기
var fs = require("fs");

fs.writeFile("./output.txt", "Hello World!", function(err) {//파일 이름 정해놔서 여러번 실행해도 파일 추가로 안생긴다.
	
	if(err) {
		console.log("Error : " + err);
	}
	
	console.log("output.txt 파일에 데이터 쓰기 완료!");
	
});
