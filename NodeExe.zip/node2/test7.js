
//파이프(pipe)
var fs = require("fs");

var inName = "./output.txt";
var outName = "./output3.txt";

fs.exists(outName,function(exists) {//outName 있으면 실행
	
	if(exists) {
		
		fs.unlink(outName,function(err) {//unlink() : 파일 있으면 기존 파일 지워라, function()안에 바꿔도 됨.
			
			if(err) throw err; //에러 발생하면 실행, 에러 메시지 띄우기
			
			console.log(outName + "삭제함..");
			
		});
		
		return; //삭제하고 끝내라.
		
	}
	
	var inFile = fs.createReadStream(inName,{flags: "r"});
	var outFile = fs.createWriteStream(outName,{flags: "w"});
	
	inFile.pipe(outFile); //pipe로 읽어들여서 내보내. test6의 on메소드 2개 합친 꼴이다.
	
	console.log("파일 복사 성공!!");
	
});

