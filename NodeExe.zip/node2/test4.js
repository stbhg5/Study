
//동기식 방식 - 파일 크면 읽어내는 시간동안 멈춰있음
var fs = require("fs"); //외부 모듈 불러옴

var data = fs.readFileSync("../data.json","UTF-8"); //동기식 방식

console.log("동기식 방식...");
console.log(data);
console.log("동기식 방식으로 data.json 파일 읽음");


//비동기식 방식
fs.readFile("../data.json","UTF-8",function(err,data) {//비동기식 방식 (에러,정상)
	console.log("비동기식 방식...");
	console.log(data);
});

console.log("비동기식 방식으로 data.json 파일 읽음"); //먼저 실행되고 비동기식 다되면 실행
