/*
* 외부 모듈 설치하기(npm,yarn)

package.json 파일생성
npm init 실행 (기본 외부모듈 설치-기본값 엔터-계속 엔터)

npm install 패키지이름 : 설치
npm uninstall 패키지이름 : 삭제

npm install -g npm : 시스템 어디서든 패키지 사용
(c:\Users\%USERNAME%\AppData\Roaming\npm\node_modules)

npm update --save : 모든 패키지 업데이트

npm install 패키지이름 --save : package.json 파일에 저장(pom.xml) (기본적인 라이브러리에 추가로 기록)
npm install : package.json 파일에 기록된 모든패키지 설치

npm 홈페이지 : https://www.npmjs.com/
yarn 홈페이지 : https://yarnpkg.com/
*/

/*
//log 기록
var winston = require("winston"); //로그처리 모듈
var winstonDaily = require("winston-daily-rotate-file"); //일별처리 모듈

//외부모듈설치 해야 createLogger(); 뜬다.
var logger = winston.createLogger({
	
	//로그수준
	//dubug:0->info:1->notice:2->warning:3->error:4->crit:5->alert:6->emerg:7
	level: "debug",
	format: winston.format.simple(), //보여지는 형식
	transports: 
		[
	             new (winston.transports.Console) ({//콘솔에 출력하라
	            	 colorize: true
	             }),
	             new (winstonDaily)({//매일 파일출력
	            	 filename: "./log/server_%DATA%.log",
	            	 maxSize: "10m",
	            	 datePattern: "YYYY-MM-DD HH-mm-ss"
	             })
	    ]
	
});
*/
//--------------------------------------------------위, 아래는 별개다.

var logger = require("./logger");

var fs = require("fs");

var inName = "./output.txt";
var outName = "./output4.txt";

fs.exists(outName,function(exists) {//outName 있으면 실행
	
	if(exists) {
		
		fs.unlink(outName,function(err) {//unlink() : 파일 있으면 기존 파일 지워라, function()안에 바꿔도 됨.
			
			if(err) throw err; //에러 발생하면 실행, 에러 메시지 띄우기
			
			logger.info(outName + "삭제함.."); //로그에 쓰기
			
		});
		
		//return; //삭제하고 다시 만들어라.
		
	}
	
	var inFile = fs.createReadStream(inName,{flags: "r"});
	var outFile = fs.createWriteStream(outName,{flags: "w"});
	
	inFile.pipe(outFile); //pipe로 읽어들여서 내보내. test6의 on메소드 2개 합친 꼴이다.
	
	logger.info("파일 복사 성공!!");
	
});
