/*
* 외부 모듈 설치하기(npm,yarn)

package.json 파일생성
npm init 실행 (기본 외부모듈 설치-기본값 엔터-계속 엔터)

npm install 모듈이름 : 설치
npm uninstall 모듈이름 : 삭제
npm install -g npm : 모든 모듈 업데이트

npm install 모듈이름 --save : package.json 파일에 저장 (기본적인 라이브러리에 추가로 기록)
npm install : package.json 파일에 기록된 모든패키지 설치

npm 홈페이지 : https://www.npmjs.com/
yarn 홈페이지 : https://yarnpkg.com/
*/

//log 기록
var winston = require("winston"); //로그처리 모듈
var winstonDaily = require("winston-daily-rotate-file"); //일별처리 모듈

//외부모듈설치 해야 createLogger(); 뜬다.
var logger = winston.createLogger();
