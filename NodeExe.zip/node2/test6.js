
//파일을 읽어서 다른 파일로 쓰기
//createReadStream
//createWriteStream

var fs = require("fs");

//flags 문법 - r:읽기 , w:쓰기, w+:(r+w-읽고쓰기), a+:(r+w 누적-append)
var inFile = fs.createReadStream("./output.txt",{flags: "r"}); //flags : 읽음
var outFile = fs.createWriteStream("./output2.txt",{flags: "w"});

inFile.on("data",function(data) {//"data" 바꾸면 안됨. 예약어. function()안에 바꿔도 됨.
	
	console.log("output.txt. 읽음..");
	outFile.write(data); //데이터 써라
	
});

inFile.on("end",function() {//"end" 바꾸면 안됨. 예약어. function()안에 바꿔도 됨.
	
	console.log("파일 읽기 종료..");
	
	outFile.end(function() {
		console.log("output2.txt 쓰기 완료");
	});
	
});
