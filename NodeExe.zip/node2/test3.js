
//2. event 사용하기 - util.inherits를 통해 EventEmitter를 상속받게 함
var Calc = require("./calc");

var calc = new Calc(); //객체생성

calc.emit("stop"); //on과 이름 동일하게

console.log(Calc.title + "에 stop 이벤트 호출."); //계산기
