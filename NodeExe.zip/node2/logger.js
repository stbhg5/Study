/*
* 외부 모듈 설치하기(npm,yarn)

package.json 파일생성
npm init 실행 (기본 외부모듈 설치-기본값 엔터-계속 엔터)

npm install 패키지이름 : 설치
npm uninstall 패키지이름 : 삭제

npm install -g npm : 시스템 어디서든 패키지 사용
(c:\Users\%USERNAME%\AppData\Roaming\npm\node_modules)

npm update --save : 모든 패키지 업데이트

npm install 패키지이름 --save : package.json 파일에 저장(pom.xml) (기본적인 라이브러리에 추가로 기록)
npm install : package.json 파일에 기록된 모든패키지 설치

npm 홈페이지 : https://www.npmjs.com/
yarn 홈페이지 : https://yarnpkg.com/
*/

//log 기록
var winston = require("winston"); //로그처리 모듈
var winstonDaily = require("winston-daily-rotate-file"); //일별처리 모듈

//외부모듈설치 해야 createLogger(); 뜬다.
var logger = winston.createLogger({
	
	//로그수준
	//dubug:0->info:1->notice:2->warning:3->error:4->crit:5->alert:6->emerg:7
	level: "debug",
	format: winston.format.simple(), //보여지는 형식
	transports: 
		[
	             new (winston.transports.Console) ({//콘솔에 출력하라
	            	 colorize: true
	             }),
	             new (winstonDaily)({//매일 파일출력
	            	 filename: "./log/server_%DATA%.log",
	            	 maxSize: "10m",
	            	 datePattern: "YYYY-MM-DD HH-mm-ss"
	             })
	    ]
	
});

module.exports = logger; //외부에서 logger 갖다쓰게 함.
