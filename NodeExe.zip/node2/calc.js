
var Calc = function() {
	
	this.on("stop",function() {//emit와 이름 동일하게
		console.log("Calc에 stop event 전달됨.");
	});
	
};

//util.inherits : 상속을 가능하게 해주는 모듈
var util = require("util");

//EventEmitter는 events 모듈안에 정의되어 있음.
var eventEmitter = require("events").EventEmitter; //event의 EventEmitter

//Calc가 이벤트를 처리할 수 있도록 EventEmitter를 상속받게 해줌
//자바로 치면 public class Calc extends EventEmitter {...}
util.inherits(Calc,eventEmitter); //Calc가 eventEmitter를 상속받음

//calc를 외부에서 인식되게 함
module.exports = Calc; //외부에서 호출 가능하게 함
module.exports.title = "계산기"; //변수만듦