
//url모듈
var url = require("url"); //나중에 필수적으로 들어간다.

//parse : 주소 문자열을 URL 문자열로 만듦
var curURL = url.parse("https://m.search.naver.com/search.naver?sm=mtp_hty.top&where=m&query=suzi");

//format : URL 문자열을 URL 객체로 만듦
var curStr = url.format(curURL);

console.log(curURL); //URL 정보 가져옴
console.dir(curURL);
console.log(curStr); //URL 보여줌

console.log("-----------------------------------------");

//요청 파라미터 구분
var querystring = require("querystring");
var param = querystring.parse(curURL.query);

console.log(param.query); //검색한 쿼리값
console.log(querystring.stringify(param)); //내부적 사용 쿼리 / 객체를 문자열로 바꿔줌
