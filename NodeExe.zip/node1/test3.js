
//내장 모듈 사용 - API에서 보면서 이렇게 사용하면 된다.
//https://nodejs.org/api/

var os = require("os"); //OS

console.log(os.hostname()); //호스트명
console.log(os.freemem()/os.totalmem()); //메모리
console.log(os.cpus()); //cpu정보 JSON형태로 보여준다.
console.log(os.networkInterfaces()); //네트워크 관련된 정보

console.log("---------------------------------------------");

var path = require("path"); //경로

var dir = ["users","itwill","docs"]; //배열 데이터
var docDir = dir.join(path.sep); //구분된것을 붙여서 집어넣음 - 폴더
console.log(docDir); //경로읽음

var curPath = path.join("/user/itwill","notepad.exe"); //경로와 파일명 붙음
console.log(curPath);

var filePath = "c:\\users\\itwill\\notepad.exe"; //주소 분리하여 가져옴
var dirName = path.dirname(filePath); //디렉토리
var fileName = path.basename(filePath); //파일명
var extName = path.extname(filePath); //확장자

console.log("디렉토리: %s, 파일이름: %s, 확장자: %s",dirName,fileName,extName);
