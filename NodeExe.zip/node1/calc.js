
//1. 속성을 사용 (exports로 분리)

exports.add = function(a,b) {//메소드 생성
	return a + b;
};