
//프로토타입 객체 만들기
function Person(name,age) {//Person클래스 만들며 변수 생성 후 생성자 만들어 초기화
	this.name = name;
	this.age = age;
}

//Person.walk = function(speed){...} : 이 방법 쓸 수 없다.
Person.prototype.walk = function(speed) {
	
	if(speed>30) {
		console.log(speed + "km 속도로 뛰어갑니다.");
		return;
	}
	
	console.log(speed + "km 속도로 걸어갑니다.");
	
}

var person1 = new Person("수지",25);
var person2 = new Person("인나",40);

console.log(person1.name + "가 걸어가고 있습니다");
person1.walk(10);

console.log(person2.name + "가 뛰어가고 있습니다");
person2.walk(40);
