
//콜백함수
//함수를 파라미터로 전달하는 경우는 대부분 비동기 방식.

function add(a,b,callback) {//메소드 이름 사용자 정의
	
	 var result = a + b;
	 
	 callback(result);
	 
};

add(10,20,function(result) {
	console.log(result); //30
});

console.log("\n------------------------------------\n");

//함수가 결과값으로 리턴됨

function add1(a,b,callback) {
	
	var result = a + b;
	
	callback(result);
	
	var history = function() {
		return a + " + " + b + " = " + result;
	}
	
	return history;
	
}

var history = add1(20,30,function(result) {
	
	console.log(result); //50
	
});

console.log(history()); //20 + 30 = 50
