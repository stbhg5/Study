
//자바스크립트의 객체 타입

var Person = {}; 

//클래스에 변수선언
Person["name"] = "배수지";
Person["age"] = 25;
Person.mobile = "010-1111-2222";

//출력법 2가지
console.log(Person.name);
console.log(Person.age);
console.log(Person.mobile);

console.log(Person["name"]);
console.log(Person["age"]);
console.log(Person["mobile"]);

console.log("--------------------------------");

/*
자바 
public int add(int a, int b) {...}

자바스크립트
function add(a,b) {...}

//변수에 함수 할당
var add = function add(a,b) {...}
var add = function(a,b) {...} - 중복된 이름만 지움
*/

function add1(a,b) {
	return a + b;
};

var result = add1(10,20);

console.log(result);

console.log("----------------------------------");

//위에 2개 작업 합침
var add2 = function(a,b) {//이모습이 많이 사용되니 익숙해지자
	return a + b;
};

var result = add2(20,30)

console.log(result);

console.log("----------------------------------");

//클래스에 함수 선언
var Person1 = {};

Person1["name"] = "유인나";
Person1["age"] = 40;
Person1.mobile = "010-2222-3333";
Person1.add3 = function(a,b) {//함수(메소드) 넣을수 있다
	return a + b;
};

console.log(Person1.name);
console.log(Person1.age);
console.log(Person1.mobile);
console.log(Person1.add3(30,40));

console.log("----------------------------------");

//함수 만든것 클래스에 넣기
var add4 = function(a,b) {
	return a + b;
};

Person1["add4"] = add4; //위 클래스에 변수 선언
console.log(Person1.add4(40,50));

console.log("----------------------------------");

//객체를 만들면서 속성을 초기화
var Person2 = {
		
		name:"정인선",
		age:27,
		add5:function(a,b) {
			return a + b;
		}

};

console.log(Person2.add5(50,60));
