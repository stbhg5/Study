
//2. 객체를 사용(module.exports 분리)

var calc = {}; //클래스 생성

calc.add = function(a,b) {//메소드 생성 - 변수에 함수 넣기
	return a + b;
};

module.exports = calc;