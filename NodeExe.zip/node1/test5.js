/*
배열 만들고 요소 추가하기
★push() : 마지막에 데이터 추가
pop() : 마지막 데이터 삭제
unshift() : 맨앞에 데이터 추가
shift() : 맨앞에 데이터 삭제
★splice() : 여러 데이터 추가/삭제
slice() : 잘라내서 새로운 배열 만들기
*/

var Users = [{name:"수지",age:25},{name:"인나",age:40}];

Users.push({name:"인선",age:27});

console.log(Users.length);

console.log(Users[0].name);
console.log(Users[1].name);
console.log(Users[2].name);

console.log(Users); //통째로 출력(JSON 형태로 출력)

console.log("----------------------------------------------");

for(var i=0;i<Users.length;i++) {//for문으로 출력
	console.log(Users[i].name + ":" + Users[i].age);
}

console.log("----------------------------------------------");

Users.forEach(function(item, index) {//List의 iterator와 같은 개념 - 반복문
	console.log(index + ":" + item.name + ":" + item.age);
});

console.log("----------------------------------------------");

//여러 데이터 추가/삭제
Users.splice(0,1); //index 0번째의 첫째 데이터, 수지 지워짐

for(var i=0;i<Users.length;i++) {//for문으로 출력
	console.log(Users[i].name + ":" + Users[i].age);
}

console.log("----------------------------------------------");

var add = function(a,b) {//배열에 함수 추가
	return a + b;
};

Users.push(add);

console.log(Users[2](10,20)); //30

for(var i=0;i<Users.length;i++) {//함수는 undefined로 뜬다.
	console.log(Users[i].name + ":" + Users[i].age);
};

console.log("----------------------------------------------");

//push
Users.push({name:"효리",age:40});
Users.push({name:"수지",age:25});

for(var i=0;i<Users.length;i++) {
	console.log(Users[i].name + ":" + Users[i].age);
};

console.log("----------------------------------------------");

//pop - 수지 삭제
Users.pop();

for(var i=0;i<Users.length;i++) {
	console.log(Users[i].name + ":" + Users[i].age);
};

console.log("----------------------------------------------");

//shift - 인나 삭제
Users.shift();

for(var i=0;i<Users.length;i++) {
	console.log(Users[i].name + ":" + Users[i].age);
};

console.log("----------------------------------------------");

//unshift - 안젤리나 맨 처음에 들어감
Users.unshift({name:"안젤리나",age:23});

for(var i=0;i<Users.length;i++) {
	console.log(Users[i].name + ":" + Users[i].age);
};

console.log("----------------------------------------------");

//delete - 중간 데이터 삭제
delete Users[1]; //인선 지워졌지만, 데이터만 지워지고 자리는 남음

console.dir(Users);

console.dir(Users.length); //4

console.log("----------------------------------------------");

//splice - 여러 데이터 추가/삭제
Users.splice(1,0,{name:"수지",age:25}); //index 1번째

console.dir(Users);

console.dir(Users.length); //5

console.log("----------------------------------------------");

//splice - 여러 데이터 추가/삭제
Users.splice(2,1); //2번째 인덱스의 1개 삭제 - <1 empty item> 삭제됨

console.dir(Users);

console.dir(Users.length); //4

console.log("----------------------------------------------");

//잘라내서 새로운 배열 만들기
var Users2 = Users.slice(1,3); //3-1 - 2개만 나옴, 실제 출력되는 인덱스 1,2

console.dir(Users);

console.dir(Users2);

var Users3 = Users2.slice(1);//0,1 중 1 잘라냄

console.dir(Users3);

var Users4 = Users.slice(1); //1부터 전부 잘라냄

console.dir(Users4);

//push, splice만 잘 기억하면 된다!! 그럼 배열 사용하는데 큰 문제 없다.
