
/*
모듈을 나누는 방법 (모듈은 메소드라고 생각하면 된다.)
1. 속성을 사용(exports로 분리)
exports.add = function(a,b) {
	return a+b;
};

exports.mul = function(a,b) {
	return a*b;
};
--------------------------------------------------------
2. 객체를 사용(module.exports 분리) - 좀 더 많이쓰는데, 일반적 프로그래머가 이해하기 쉬운 개념
var Calc = {}; //클래스 생성

Calc.add = function(a,b) {//메소드 생성
	return a+b;
};

Calc.mul = function(a,b) {//메소드 생성
	return a*b;
};

module.exports = Calc; //이렇게 사용

모듈 분리 이유 : 나중에 코딩 많아진것 따로 파일로 만들어
각각의 파일 통해 require로 코딩 불러올 수 있다.
 */

var calc = {};

calc.add = function(a,b) {
	return a + b;
};

console.log("모듈 분리전 함수 add 호출 : %d",calc.add(10,20));

var calc1 = require("./calc"); //calc.js 호출
console.log("모듈 분리후 함수 add 호출 : %d",calc1.add(100,200));

var calc2 = require("./calc2"); //calc2.js 호출
console.log("모듈 분리후 함수 add 호출 : %d",calc2.add(1,2));
