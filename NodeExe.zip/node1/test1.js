
/*
전역객체와 메소드 (내장되어 있는 객체)
console(출력) : log, dir, time, timeEnd - 메소드
process(프로세스 실행) : argv, env, exit(종료)
exports(모듈 - import개념)
*/

//console
var result = 0;

console.log("console-------");

console.time("계산시간"); //들어가는 문구 내 마음대로

for(var i=0;i<=1000;i++) {
	result += i;
}

console.timeEnd("계산시간"); //위 console.time 문자와 똑같아야 한다!!

console.log("1부터 1000까지의 합 : %d",result);

console.log("현재 실행할 파일 이름: %s",__filename); //많이 사용한다.
console.log("현재 실행할 파일 경로: %s",__dirname);

var Person = {name:"인나",age:"40"}; //변수가 대문자면 클래스
console.dir(Person); //객체의 모습 그대로 보이게 된다!!


//process
console.log("\nprocess-------");
console.log("argv속성의 파라미터 갯수:" + process.argv.length); //2 - 인수값 2개
console.dir(process.argv); //노드의 위치, 현재 실행하는 파일 위치

process.argv.forEach(function(item,index) {//반복문
	console.log(index + ":" + item);
});

console.dir(process.env); //환경변수의 내용 보여준다. JSON형태로 보여줌 : 자바스크립트 기본 데이터 처리법

