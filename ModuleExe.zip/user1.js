
//모듈 분리 : 기능별로 독립된 파일로 분리

//exports 함수로 객체 추가
exports.getUser = function() {
	return {id:"suzi",name:"수지"};
}

//exports 객체 속성으로 객체 추가
exports.group = {id:"inna",name:"인나"};