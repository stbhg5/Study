
//2. 인스턴스 객체 할당(모듈을 불러온 후 객체의 메소드나 속성을 호출)
function User(id,name) {//생성자 지정, 인스턴스 객체에 의해 초기화
	this.id = id;
	this.name = name;
};

User.prototype.printUser = function() {
	console.log("아이디: " + this.id + ", 이름: " + this.name);
};

module.exports = new User("suzi","배수지"); //인스턴스 객체
