
var User = require("./user8");

var user = new User("insun","인선");

user.printUser();
