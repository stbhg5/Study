
//환경설정 파일
module.exports = {
		
		serverPort: 3000,
		dbUrl: "mongodb://localhost:27017/shopping",
		
		dbSchemas:[//file위치는 database.js 입장으로 적음 //앞으로 개수 많아진다.
		           {file:"./userSchema",collection:"users3",schemaName:"UserSchema",modelName:"UserModel"} //이름 사용자 정의
		          ],
		          
		routerInfo:[//4개(파일,경로,메소드,방식) 정보 들어감
		            {file:"./user",path:"/process/login",method:"login",type:"post"},
		            {file:"./user",path:"/process/addUser",method:"addUser",type:"post"},
		            {file:"./user",path:"/process/listUser",method:"listUser",type:"post"}
		           ]
		
}
