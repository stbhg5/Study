
//모듈 분리 : 기능별로 독립된 파일로 분리

//곧죽어도 exports 쓰고 싶을 때
module.exports = function() {
		
	return {id:"suzi",name:"수지"};
	
};

