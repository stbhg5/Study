
//모듈 분리 : 기능별로 독립된 파일로 분리

//var user로 만들기
var user = {
		
	getUser:function() {
		return {id:"suzi",name:"수지"};
	},
	group:{id:"inna",name:"인나"}

};

module.exports = user;
