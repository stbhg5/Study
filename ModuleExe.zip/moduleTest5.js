
//require() 메소드는 exports 객체를 리턴함
var user = require("./user5");

function showId() {
	return user.getUser().id + ", " + user.group.id;
}

function showName() {
	return user.getUser().name + ", " + user.group.name;
}

console.log("아이디 정보: " + showId());
console.log("이름 정보: " + showName());
