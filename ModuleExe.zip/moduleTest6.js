
var printUser = require("./user6").printUser;

printUser();
