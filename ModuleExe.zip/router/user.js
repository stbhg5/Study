
/*
var database;
var UserSchema;
var UserModel;

var init = function(db,schema,model) {
	
	console.log("init 호출");
	
	database = db;
	UserSchema = schema;
	UserModel = model;
	
}
*/
//moment 모듈
var moment = require("moment"); //날짜 보기 설정

//라우터 객체 3개
var login = function(req,res) {
	
	console.log("user.js 안에 login 호출");
	
	var id = req.body.id;
	var pwd = req.body.pwd;
	
	var database = req.app.get("database"); //database 호출, app.set으로 넣었으니
	
	//사용자 인증
	if(database) {//database 연결되어야 있어야함
		
		authUser(database, id, pwd, function(err,result) {//callback함수
			
			if(err) {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'/>");
				res.write("<h1>사용자 로그인 에러!!</h1>");
				res.end();
				
				return;
				
			}
			
			if(result) {//result 있으면
				
				var userName = result[0].name;
				
				//뷰 템플릿을 이용해서 렌더링 후 전송
				var context = {userId:id,userName:userName}
				
				//app.render : 뷰엔진 호출
				//login : login.ejs(템플릿 이름)
				//req.app.render("login",context,function(err,html) 
				req.app.render("login_Success",context,function(err,html) {//render가 login.ejs와 context 합쳐져 겉모습 만들고 클라이언트에게 보내면서 끝
					
					if(err) {
						
						res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
						res.write("<h2>뷰 렌더링 중 에러발생</h2>");
						res.end();
						
						return;
						
					}
					
					//console.log(html);
					res.end(html);
					
				});
				
			}else {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'/>");
				res.write("<h1>로그인 실패!!</h1>");
				res.write("<div>아이디와 패스워드를 다시 확인하세요.</div>");
				res.write("<br/><br/><a href='/public1/login.html'>로그인</a>");
				res.write("<br/><br/><a href='/public1/listUser.html'>리스트</a>");
				res.end();
				
			}
			
		});
		
	}else {
		
		res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
		res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'/>");
		res.write("<h1>데이터베이스 연결 실패!!</h1>");
		res.write("<div>데이터베이스에 연결하지 못했습니다.</div>");
		res.end();
		
	}
	
};

var addUsers = function(req,res) {
	
	console.log("user.js 안에 addUser 호출");
	
	var id = req.body.id;
	var pwd = req.body.pwd;
	var name = req.body.name;
	
	var database = req.app.get("database"); //database 호출
	
	if(database) {
		
		addUser(database, id, pwd, name, function(err,result) {//이름 겹치면 안됨
			
			if(err) {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'/>");
				res.write("<h1>사용자 추가 에러!!</h1>");
				res.end();
				
				return;
				
			}
			
			if(result) {//검증
				
				//뷰 템플릿을 이용해서 렌더링 후 전송
				var context = {title:"사용자 추가 성공(View - ejs)"}
				
				req.app.render("addUser",context,function(err,html) {
					
					if(err) {
						
						res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
						res.write("<h2>뷰 렌더링 중 에러발생</h2>");
						res.end();
						
						return;
						
					}
					
					//console.log(html);
					res.end(html);
					
				});
				
			}else {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'/>");
				res.write("<h1>사용자 추가 실패!!</h1>");
				res.write("<br/><br/><a href='/public1/login.html'>로그인</a>");
				res.write("<br/><br/><a href='/public1/listUser.html'>리스트</a>");
				res.end();
				
			}
			
		});
		
	}else {
		
		res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
		res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'/>");
		res.write("<h1>데이터베이스 연결 실패!!</h1>");
		res.write("<div>데이터베이스에 연결하지 못했습니다.</div>");
		res.end();
		
	}
	
};

var listUser = function(req,res) {
	
	var database = req.app.get("database"); //database 호출
	
	if(database) {
		
		//모든 사용자 검색
		database.UserModel.findAll(function(err,result) {//model의 스키마 메소드 부르기
			
			if(err) {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'/>");
				res.write("<h1>사용자 리스트 조회중 에러 발생</h1>");
				res.end();
				
				return;
				
			}
			
			if(result) {
				
				//뷰 템플릿을 이용해서 렌더링 후 전송
				//var context = {result:result};
				var context = {result:result, moment:moment};
				
				//req.app.render("listUserResp",context,function(err,html)
				//req.app.render("listUser_Success",context,function(err,html)
				req.app.render("listUserResp_Success",context,function(err,html) {
					
					if(err) {
						
						res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
						res.write("<h2>뷰 렌더링 중 에러발생</h2>");
						res.end();
						
						return;
						
					}
					
					//console.log(html);
					res.end(html);
					
				});
				
			}else {
				
				res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
				res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'/>");
				res.write("<h1>사용자 리스트 조회 실패</h1>");
				res.end();
				
			}
			
		});
		
	}else {
		
		res.writeHead("200",{"Content-Type":"text/html;charset=utf-8"});
		res.write("<meta name='viewport' content='width=device-width, height=device-height, initial-scale=1'/>");
		res.write("<h1>데이터베이스 연결 실패!!</h1>");
		res.write("<div>데이터베이스에 연결하지 못했습니다.</div>");
		res.end();
		
	}
	
}

//함수 2개 - 라우터 내부에서 사용함

//사용자 인증 함수 (로그인할 때 사용)
var authUser = function(database,id,password,callback) {
	
	console.log("authUser 호출");
	
	//id를 이용해서 검색
	//매개변수로 database 받음
	database.UserModel.findById(id,function(err,result) {//callback 함수
		
		if(err) {
			callback(err,null); //에러만 전달하고 데이터는 null전달
			return;
		}
		
		if(result.length>0) {//데이터 찾음
			
			var user = new database.UserModel({id:id});
			
			var authenticate = user.authenticate(password,result[0]._doc.salt,result[0]._doc.hashed_password);
			
			if(authenticate) {
				console.log("비밀번호 일치함.");
				callback(null,result);
			}else {
				console.log("비밀번호 일치하지 않음.");
				callback(null,null);
			}
			
		}else {//사용자 찾지 못함
			
			console.log("아이디와 일치하는 사용자를 찾지 못함");
			callback(null,null); //에러는 아닌데 일치사용자 없음
			
		}
		
	});
	
};

//사용자 추가 함수
var addUser = function(database,id,pwd,name,callback) {
	
	console.log("addUser 호출");
	
	//var users = database.collection("users");
	
	//매개변수로 database 받음
	var user = new database.UserModel({"id":id,"password":pwd,"name":name});
	
	user.save(function(err,result) {
		
		if(err) {
			callback(err,null);
			return;
		}
		/*
		if(result.insertedCount>0) {//배열검증
			
		}
		*/
		
		if(result) {
			console.log("사용자 추가");
		}else {
			console.log("사용자 추가 안됨");
		}
		
		callback(null,result);
		
	});
	
};

//외부 사용 가능하도록
//module.exports.init = init;

module.exports.login = login;
module.exports.addUser = addUsers;
module.exports.listUser = listUser;
