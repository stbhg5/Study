
//모듈 분리 : 기능별로 독립된 파일로 분리
//module.exports와 exports.group 같이 씀 (exports.group 무시됨)
module.exports = {
		
	getUser:function() {
		return {id:"suzi",name:"수지"};
	},
	group:{id:"inna",name:"인나"}

};

exports.group = {id:"an",name:"안젤리나"};
