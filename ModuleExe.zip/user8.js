
//3. 프로토타입 객체 할당(모듈을 불러온 후 new 객체 생성 후 실행)
function User(id,name) {//생성자 지정, 인스턴스 객체에 의해 초기화 //세터
	this.id = id;
	this.name = name;
};

User.prototype.getUser = function() {//게터
	return {id:this.id, name:this.name};
};

User.prototype.group = {id:"inna",name:"인나"};

User.prototype.printUser = function() {
	console.log("아이디: " + this.id + ", 이름: " + this.name);
	console.log("아이디: " + this.group.id + ", 이름: " + this.group.name);
};

module.exports = User; //인스턴스 객체
