
//require() 메소드는 exports 객체를 리턴함
var user = require("./user4");

function showUser() {
	return user().id + ", " + user().name;
}

console.log("사용자 정보: " + showUser());
