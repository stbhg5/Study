
//모듈 분리 : 기능별로 독립된 파일로 분리

//exports객체만 만들기 - null 나온다. 새롭게 객체 만들어지기 때문.
//exports 자체엔 집어넣을 수 없다.
exports = {
		
	getUser:function() {
		return {id:"suzi",name:"수지"};
	},
	group:{id:"inna",name:"인나"}

};
