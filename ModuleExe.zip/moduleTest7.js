
var user = require("./user7");

user.printUser();
