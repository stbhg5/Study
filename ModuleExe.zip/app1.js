
//http://localhost:3000/public/login.html - 로그인
//http://localhost:3000/public/addUser.html - 회원가입
//http://localhost:3000/public/listUser.html - 리스트
//모듈화 - 분리하기 어렵지만 변해가는 모습 보면서 익혀야 한다.
//Schema,라우터&함수 모듈화

var express = require("express");
var http = require("http");
var path = require("path");

var serveStatic = require("serve-static"); //특정 폴더로 접근 가능하게 함
var expressErrorHandler = require("express-error-handler");
var cookieParser = require("cookie-parser");
var expressSession = require("express-session");

var mongoose = require("mongoose");

//user.js 모듈
var user = require("./router/user");

//익스프레스 객체 생성
var app = express(); 

//기본 포트를 app객체에 속성으로 설정
//express 객체의 메소드 (set,get,use)
app.set("port",process.env.PORT || 3000);

//미들웨어 추가
app.use(express.urlencoded({extended: true})); 
app.use(express.json()); 

//사용할 주소 /public
app.use("/public",serveStatic(path.join(__dirname,"public")));



//데이터베이스 객체를 위한 변수
var database;

//데이터베이스 컬렉션에 적용할 스키마 객체를 위한 변수
var UserSchema; //규칙 만들기

//데이터베이스 모델 객체를 위한 변수
var UserModel; //규칙 적용

function connectDB() {
	
	//데이터베이스 연결 정보
	var databaseUrl = "mongodb://localhost:27017/shopping"; //아이피주소보다 localhost
	
	//몽구스로 데이터베이스 연결 - MongoDB연결에는 이 기능이 없다.
	mongoose.connect(databaseUrl); //DB 연결
	database = mongoose.connection; //DB연결되던 안되던 무조건 on 실행
	//모듈 내부적 emit가지고 있어서 자동으로 open이나 error,disconnected (예약어)찾아가게 한다.
	
	database.on("open",function() {//이벤트, 예약어
		
		console.log("데이터베이스에 연결되었습니다. : " + databaseUrl);
		
		createUserSchema();
		
	});
	
	database.on("error",console.error.bind(console,"몽구스 연결 에러.."));
	
	database.on("disconnected",function() {
		
		console.log("데이터베이스 연결이 끊겼습니다");
		setInterval(connectDB,5000); //연결이 끊기면 5초후 재연결
		
	});
	
}


//스키마 및 모델 객체 생성 함수
function createUserSchema() {
	
	//userSchema.js 모듈 불러오기
	UserSchema = require("./database/userSchema").createSchema(mongoose);
	
	//Schema를 collection에 model로 적용
	UserModel = mongoose.model("users3",UserSchema); //insert시에 자동으로 컬렉션 만들어진다.
	console.log("UserModel 정의함");
	
	//모듈 위에 만듦
	user.init(database,UserSchema,UserModel); //좋은 방법은 아니다.
	
}



//라우터 객체
var router = express.Router();

//사용자 로그인 라우터
router.route("/process/login").post(user.login);

//사용자 추가 라우터
router.route("/process/addUser").post(user.addUser);

//사용자 리스트 함수
router.route("/process/listUser").post(user.listUser);

//라우터 등록
app.use("/",router);

app.use(cookieParser());

app.use(expressSession({
	secret: "my key", //아무거나 써도 됨 - 가져가서 암호화 시킴
	resave: true, //일반적으로 true
	saveUninitialized: true //일반적으로 true - 세션 공간 초기화
}));

//404에러 페이지
var errorHandler = expressErrorHandler({
	
	static:{//404에러나면 html 찾아가라
		'404' : "./public/404.html"
	}
	
});

app.use(expressErrorHandler.httpError(404));
app.use(errorHandler);

//Express서버 시작
http.createServer(app).listen(app.get("port"),function() {
	
	console.log("Express 서버를 시작했습니다 : " + app.get("port"));
	
	connectDB(); //DB연결 함수 실행
	
});
