
//집 IP : 175.192.255.145
//학원컴퓨터 IP : 192.168.63.30
//http://localhost:3000/ - index
//http://localhost:3000/public/login.html - 로그인
//http://localhost:3000/public/addUser.html - 회원가입
//http://localhost:3000/public/listUser.html - 리스트
//http://localhost:3000/public/listUserResp.html - 불러온 리스트
//http://localhost:3000/public/login.html1 - 에러

//모듈화 passport, localLogin, localSignup, 라우터

var express = require("express");
var http = require("http");
var path = require("path");

var serveStatic = require("serve-static"); //특정 폴더로 접근 가능하게 함
var expressErrorHandler = require("express-error-handler");
var cookieParser = require("cookie-parser");
var expressSession = require("express-session");

//var mongoose = require("mongoose");

var passport = require("passport");
var flash = require("connect-flash"); //메세지 전달

//user.js 모듈
//var user = require("./router/user"); //.js 안 붙여도 된다

//config.js 모듈
var config = require("./config/config");

//database.js 모듈
var database = require("./database/database");

//routerLoader.js 모듈
var routerLoader = require("./router/routerLoader");

//익스프레스 객체 생성
var app = express(); 

//기본 포트를 app객체에 속성으로 설정
//express 객체의 메소드 (set,get,use)
app.set("port",process.env.PORT || config.serverPort);
//app.set("port",process.env.PORT || 3000);

//뷰엔진 설정
app.set("views",__dirname + "/views"); //views는 문법이다.
app.set("view engine","ejs");
console.log("뷰 엔진은 ejs로 설정되었습니다.");

//app.set("view engine","jade");
//console.log("뷰 엔진은 jade로 설정되었습니다.");

//미들웨어 추가
app.use(express.urlencoded({extended: true})); 
app.use(express.json());

//사용할 주소 /public
app.use("/public",serveStatic(path.join(__dirname,"public")));
/*
//라우터 객체생성
var router = express.Router();
routerLoader.init(app,router);
*/
app.use(cookieParser());

app.use(expressSession({
	secret: "my key", //아무거나 써도 됨 - 가져가서 암호화 시킴
	resave: true, //일반적으로 true
	saveUninitialized: true //일반적으로 true - 세션 공간 초기화
}));

//Passport 사용 : 반드시 세션 아래에 코딩
//Passport의 두개의 함수를 호출했을 때 반환하는 객체를 미들웨어로 등록
app.use(passport.initialize());
app.use(passport.session());
app.use(flash());

//라우터 객체생성 : 순서 무조건 app.use(flash());다음에 두기
var router = express.Router();
routerLoader.init(app,router);

//Passport 설정
var configPassport = require("./passport/passport");
configPassport(app,passport);

//Passport 라우팅 설정
var userPassport = require("./router/userPassport");
userPassport(router,passport);

/*
클라이언트 요청	  웹서버			뷰템플릿

홈화면조회		/				홈화면(index.ejs)
로그인화면조회	/login(get)		로그인화면(login.ejs)
로그인요청		/login(post)	로그인처리(함수) - abc_ok.jsp같은 원리
회원가입조회	/signup(get)	회원가입화면(signup.ejs)
회원가입요청	/signup(post)	회원가입처리(함수)
사용자프로필	/profile(get)	프로필화면(profile.ejs)
로그아웃요청	/logout(get)	로그아웃처리(함수)
*/
/*
//홈화면 조회 - index.ejs
router.route("/").get(function(req,res) {
	
	res.render("index.ejs");
	
});

//로그인화면조회 - login(get)		로그인화면(login.ejs)
router.route("/login").get(function(req,res) {
	
	res.render("login.ejs",{message:req.flash("loginMessage")});
	
});

//로그인요청 - login(post)	로그인처리(함수) - abc_ok.jsp같은 원리
router.route("/login").post(passport.authenticate("local-login",{
	
	successRedirect: "/profile", //로그인성공시
	failureRedirect: "/login", //로그인실패시
	failureFlash: true //실패시 flash메세지가 응답 페이지에 전달 되도록 함
	
}));

//회원가입조회 - signup(get)	회원가입화면(signup.ejs)
router.route("/signup").get(function(req,res) {
	
	res.render("signup.ejs",{message:req.flash("signupMessage")});
	
});

//회원가입요청 - signup(post)	회원가입처리(함수)
router.route("/signup").post(passport.authenticate("local-signup",{
	
	successRedirect: "/profile", //성공시
	failureRedirect: "/signup", //실패시
	failureFlash: true //실패시 flash메세지가 응답 페이지에 전달 되도록 함
	
}));

//사용자프로필 - profile(get)	프로필화면(profile.ejs)
router.route("/profile").get(function(req,res) {
	
	//인증이 안된경우
	if(!req.user) {
		
		res.redirect("/"); //index.ejs
		return;
		
	}
	
	//인증이 된경우
	if(Array.isArray(req.user)) {
		
		res.render("profile.ejs",{user:req.user[0]._doc});
		
	}else {//여러명 아니면
		
		res.render("profile.ejs",{user:req.user});
		
	}
	
});

//로그아웃요청 - logout(get)	로그아웃처리(함수)
router.route("/logout").get(function(req,res) {
	
	req.logout();
	res.redirect("/"); //index.ejs
	
});
*/

/*
//로그인 추가
//Passport Strategy 설정
//인증방식 모듈
var LocalStrategy = require("passport-local").Strategy;

//passport 로그인 설정
passport.use("local-login", new LocalStrategy({
	
	usernameField:"email",
	passwordField:"pwd",
	
	//아래 콜백함수의 첫번째 인수로 req 객체를 전달
	passReqToCallback : true
	},function(req,email,pwd,done) {
		
		//데이터베이스 객체
		var database = app.get("database");
		
		database.UserModel.findOne({"email":email},function(err,user) {
			
			if(!user) {//등록된 사용자가 없는 경우
				
				//검증콜백에서 두번째 인수값을 false로 하면 인증 실패한 것으로 처리
				return done(null,false,req.flash("loginMessage","등록된 계정이 없습니다."));
				
			}
			
			//비밀번호가 맞지 않는 경우
			var authenticated = user.authenticate(pwd,user._doc.salt,user._doc.hashed_password);
			
			if(!authenticated) {
				
				return done(null,false,req.flash("loginMessage","비밀번호가 일치하지 않습니다."));
				
			}
			
			//email,pwd 일치
			return done(null,user);
			
		});
		
	}
	
));

//passport 회원가입 설정
passport.use("local-signup",new LocalStrategy({
	
	usernameField:"email",
	passwordField:"pwd",
	passReqToCallback: true
	},function(req,email,pwd,done) {
		
		var name = req.body.name;
		
		//findOne메소드가 blocking이 되지 않게 async방식(동기화방식)으로 변경
		process.nextTick(function() {
			
			var database = app.get("database");
			
			database.UserModel.findOne({"email":email},function(err,user) {
				
				if(err) {
					return done(err);
				}
				
				//이미 사용자가 있는경우
				if(user) {
					
					return done(null,false,req.flash("signupMessage","계정이 이미 있습니다."));
					
				}else {
					
					//모델 인스턴스 객체를 만들어 저장
					var user = new database.UserModel({"email":email,"password":pwd,"name":name});
					
					user.save(function(err) {
						
						if(err) throw err;
						
						return done(null,user);
						
					});
					
				}
				
			});
			
		});
		
	}
	
));
*/

/*
//serializeUser() : 사용자 인증 성공시 자동으로 호출
//사용자 정보를 이용해서 세션 만듦
passport.serializeUser(function(user,done) {
	console.log("serializeUser 호출");
	console.log(user);
	
	done(null,user); //이 인증을 콜백에서 넘겨주는 user객체정보로 세션 생성
})

//deserializeUser() : 사용자 인증 이후 사용자 요청시마다 호출
//user : 사용자 인증 성공시 serializeUser메소드를 이용해 만든 세션 정보가 파라미터로 넘어옴
passport.deserializeUser(function(user,done) {
	console.log("deserializeUser 호출");
	console.log(user);
	
	//사용자 정보 중에 id나 email만 있는 경우 사용자 정보 조회가 필요
	//여기서는 user객체 전체를 passport에서 관리
	//두번째 파라미터로 지정된 사용자 정보(user)는 req.user객체로 복원됨
	done(null,user);
	
});
*/

//404에러 페이지
var errorHandler = expressErrorHandler({
	
	static:{//404에러나면 html 찾아가라
		'404' : "./public/404.html"
	}
	
});

app.use(expressErrorHandler.httpError(404));
app.use(errorHandler);

//에러가 나도 서버가 종료되는 것을 방지
process.on("uncaughException",function(err) {
	
	console.log("서버프로세스 종료하지 않고 유지함.");
	
});

//Express서버 시작
var host = "localhost"; //IP (CMD ipconfig) - 바뀐다, localhost로 하면 핸드폰 접속 불가
//var host = "192.168.63.30"; //학원컴퓨터

http.createServer(app).listen(app.get("port"),host,function() {
	
	console.log("Express 서버를 시작했습니다 : " + app.get("port"));
	
	//connectDB(); //DB연결 함수 실행
	
	//데이터베이스 초기화
	database.init(app,config); //app은 express 서버, ★config는 config.js
	
});
