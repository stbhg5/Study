

var add = function (req,res){
	
	console.log("add 호출");
	
	var name = req.body.name;
	var address = req.body.address;
	var tel = req.body.tel;
	var longitude = req.body.longitude;;
	var latitude = req.body.latitude;
		
	var database = req.app.get("database");
	
	if(database){
		
		
		addCoffeeShop(database,name,address,tel,longitude,latitude,function(err,result){
			
			if(err){
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, " +
				"height=device-height, initial-scale=1'>");				
				res.write("<h2>스타벅스 추가 중 에러 발생</h2>");				
				res.end();
				
				return;
			}
			
			
			if(result){
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, " +
				"height=device-height, initial-scale=1'>");		
				res.write("<h2>스타벅스 추가 성공</h2>");				
				res.end();
				
			}else{
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, " +
				"height=device-height, initial-scale=1'>");		
				res.write("<h2>스타벅스 추가 실패</h2>");				
				res.end();
				
			}
			
		});
		
	}else{
		
		res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
		res.write("<meta name='viewport' content='width=device-width, " +
		"height=device-height, initial-scale=1'>");		
		res.write("<h2>데이터베이스 연결 실패</h2>");				
		res.end();
		
	}
	
};


//추가 함수
var addCoffeeShop = function(database,name,address,tel,longitude,latitude,callback){
		
	var coffeeshop = new database.CoffeeShopModel(
				{name:name,address:address,tel:tel,
					geometry:{
						type:"Point",
						coordinates:[longitude,latitude]
					}}	
				);
	
	coffeeshop.save(function(err){
		if(err){
			callback(err,null);
			return;
		}
		
		callback(null,coffeeshop);
		
	});	
	
};

var list = function(req,res){
	
	console.log("list 호출");
	
	var database = req.app.get("database");
	
	if(database){
		
		//모든데이터 검색
		database.CoffeeShopModel.findAll(function(err,result){
			
			if(err){
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, " +
				"height=device-height, initial-scale=1'>");				
				res.write("<h2>스타벅스 조회 중 에러 발생</h2>");				
				res.end();
				
				return;
			}
			
			if(result){
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, " +
				"height=device-height, initial-scale=1'>");		
				res.write("<h2>스타벅스 리스트</h2>");	
				res.write("<div><ul>");
				
				for(var i=0;i<result.length;i++){
					
					var name = result[i]._doc.name;
					var address = result[i]._doc.address;
					var tel = result[i]._doc.tel;
					var longitude = result[i]._doc.geometry.coordinates[0];//경도
					var latitude = result[i]._doc.geometry.coordinates[1];//위도
					
					res.write("<li>#" + (i+1) + " : " +
							name + ", " +
							address + ", " +
							tel + ", " +
							longitude + ", " +
							latitude + "</li>"); 
					
				}
				
				res.write("</ul></div>");
				res.end();
				
			}else{
				
				res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
				res.write("<meta name='viewport' content='width=device-width, " +
				"height=device-height, initial-scale=1'>");		
				res.write("<h2>스타벅스 조회 실패</h2>");				
				res.end();
				
			}
			
		});
		
	}else{
		
		res.writeHead("200",{"Content-Type":"text/html;charset=UTF-8"});
		res.write("<meta name='viewport' content='width=device-width, " +
		"height=device-height, initial-scale=1'>");		
		res.write("<h2>데이터베이스 연결 실패</h2>");				
		res.end();
		
	}
	
}


module.exports.add = add;
module.exports.list = list;





















