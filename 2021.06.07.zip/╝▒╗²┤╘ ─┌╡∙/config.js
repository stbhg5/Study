

module.exports = {
		
		serverPort: 3000,
		dbUrl: "mongodb://localhost:27017/shopping",
		
		dbSchemas:[
		 {file:"./userSchema",collection:"users4",schemaName:"UserSchema",modelName:"UserModel"},
		 {file:"./coffeeshopSchema",collection:"starbucks",schemaName:"CoffeeShopSchema",
			 modelName:"CoffeeShopModel"}
		],
		
		routerInfo:[
		 	{file: "./coffeeshop", path:"/process/addCoffeeShop",method:"add",type:"post"},
		 	{file: "./coffeeshop", path:"/process/listCoffeeShop",method:"list",type:"post"},
		 	{file: "./coffeeshop", path:"/process/nearCoffeeShop",method:"findNear",type:"post"}
		            
		]
		
}