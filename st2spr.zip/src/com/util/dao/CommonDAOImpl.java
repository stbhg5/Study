package com.util.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.stereotype.Repository;

import com.ibatis.sqlmap.client.SqlMapClient;

@Repository("dao")
public class CommonDAOImpl implements CommonDAO {
	
	@Autowired
	private SqlMapClientTemplate SqlMapClientTemplate; //������̼����� xml���Ͽ� bean id="SqlMapClientTemplate" �ҷ���

	//���� �����̴�
	@Override
	public void insertData(String id, Object value) throws SQLException {
		
		try {
			
			SqlMapClientTemplate.getSqlMapClient().startTransaction(); //����
			SqlMapClientTemplate.getSqlMapClient().getCurrentConnection().setAutoCommit(false); //�ڵ�commit false
			
			SqlMapClientTemplate.insert(id, value); //���� ibatis ����
			
			SqlMapClientTemplate.getSqlMapClient().getCurrentConnection().commit(); //commit
			
		} catch (Exception e) {
			System.out.println(e.toString());
		} finally {
			SqlMapClientTemplate.getSqlMapClient().getCurrentConnection().setAutoCommit(true);
			SqlMapClientTemplate.getSqlMapClient().endTransaction(); //�Ƚᵵ ��� ������ �� ���� Ȯ���ϰ� ���ش�.
		}
		
	}

	@Override
	public int updateData(String id, Object value) throws SQLException {
		
		int result = 0;
		
		try {
			
			result = SqlMapClientTemplate.update(id,value);
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return result;
		
	}

	@Override
	public int updateData(String id, Map<String, Object> map) throws SQLException {
		
		int result = 0;
		
		try {
			
			result = SqlMapClientTemplate.update(id,map);
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return result;
		
	}

	@Override
	public int deleteAllData(String id) throws SQLException {
		
		int result = 0;
		
		try {
			
			result = SqlMapClientTemplate.delete(id);
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return result;
		
	}

	@Override
	public int deleteData(String id, Map<String, Object> map) throws SQLException {
		
		int result = 0;
		
		try {
			
			result = SqlMapClientTemplate.delete(id,map);
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return result;
		
	}

	@Override
	public int deleteData(String id, Object value) throws SQLException {
		
		int result = 0;
		
		try {
			
			result = SqlMapClientTemplate.delete(id,value);
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return result;
		
	}

	@Override
	public Object getReadData(String id) throws SQLException {
		
		try {
			return SqlMapClientTemplate.queryForObject(id);
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return null;
		
	}

	@Override
	public Object getReadData(String id, Map<String, Object> map) throws SQLException {
		
		try {
			return SqlMapClientTemplate.queryForObject(id,map);
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return null;
		
	}

	@Override
	public Object getReadData(String id, Object value) throws SQLException {
		
		try {
			return SqlMapClientTemplate.queryForObject(id,value);
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return null;
		
	}

	@Override
	public int getIntValue(String id) throws SQLException {
		
		try {
			return ((Integer)SqlMapClientTemplate.queryForObject(id)).intValue();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return 0;
		
	}

	@Override
	public int getIntValue(String id, Map<String, Object> map) throws SQLException {

		try {
			return ((Integer)SqlMapClientTemplate.queryForObject(id,map)).intValue();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return 0;
		
	}

	@Override
	public int getIntValue(String id, Object value) throws SQLException {
		
		try {
			return ((Integer)SqlMapClientTemplate.queryForObject(id,value)).intValue();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return 0;
		
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Object> getListData(String id) {
		
		try {
			return (List<Object>)SqlMapClientTemplate.queryForList(id);
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return null;
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object> getListData(String id, Object value) {
		
		try {
			return (List<Object>)SqlMapClientTemplate.queryForList(id,value);
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return null;
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object> getListData(String id, Map<String, Object> map) {
		
		try {
			return (List<Object>)SqlMapClientTemplate.queryForList(id,map);
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return null;
		
	}
	
}
